#生成论文数据预处理章节所需的5+张图
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from scipy.interpolate import interp1d
import warnings
warnings.filterwarnings('ignore')
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.lines import Line2D

# 中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.dpi'] = 150

BASE = r'C:\Users\ASUS2\Desktop\新图\C题\C题'
OUT  = BASE + r'\preprocess\output'

#  读取数据 
df1 = pd.read_excel(BASE + r'\附件\附件1.xlsx')
price1 = df1.iloc[:,1].values
load1  = df1.iloc[:,2].values
pv1    = df1.iloc[:,3].values

df2_load = pd.read_excel(BASE + r'\附件\附件2.xlsx', sheet_name='小区负载')
df2_pv   = pd.read_excel(BASE + r'\附件\附件2.xlsx', sheet_name='光伏发电实际功率')
dates    = pd.to_datetime(df2_load.iloc[:,0])
load2    = df2_load.iloc[:,1:145].values.astype(float)   # (365,144)
pv2      = df2_pv.iloc[:,1:145].values.astype(float)     # (365,144)

df3      = pd.read_excel(BASE + r'\附件\附件3.xlsx')
df4      = pd.read_excel(BASE + r'\附件\附件4.xlsx', header=0, index_col=0)
prices4  = df4.values.astype(float)                      # (365,144)

time_labels = [f'{h:02d}:{m:02d}' for h in range(24) for m in range(0,60,10)]
tick_pos  = list(range(0,144,12))
tick_lab  = [time_labels[i] for i in tick_pos]
months    = dates.dt.month

# 图1: 典型日全要素展示（电价/负载/光伏）
fig, axes = plt.subplots(3,1, figsize=(12,9), sharex=True)
x = np.arange(144)

ax = axes[0]
ax.plot(x, price1, color='#e74c3c', lw=1.8, label='电价（元/kWh）')
ax.fill_between(x, price1, alpha=0.15, color='#e74c3c')
ax.set_ylabel('电价（元/kWh）', fontsize=11)
ax.set_title('典型日电价曲线', fontsize=11, fontweight='bold')
ax.legend(fontsize=9); ax.grid(alpha=0.3)

ax = axes[1]
ax.plot(x, pv1, color='#FFD700', lw=1.8, label='光伏预测功率（kW）')
ax.fill_between(x, pv1, alpha=0.2, color='#FFD700')
ax.set_ylabel('光伏功率（kW）', fontsize=11)
ax.set_title('典型日光伏预测功率曲线', fontsize=11, fontweight='bold')
ax.legend(fontsize=9); ax.grid(alpha=0.3)
ax.set_xticks(tick_pos); ax.set_xticklabels(tick_lab, rotation=45, fontsize=8)
ax.set_xlabel('时刻', fontsize=11)

ax = axes[2]
ax.plot(x, load1, color='#9400D3', lw=1.8, label='小区负载（kW）')
ax.fill_between(x, load1, alpha=0.15, color='#9400D3')
ax.set_ylabel('负载（kW）', fontsize=11)
ax.set_title('典型日负载曲线', fontsize=11, fontweight='bold')
ax.legend(fontsize=9); ax.grid(alpha=0.3)

plt.suptitle('典型日电价、负载与光伏预测功率全要素展示', fontsize=13, fontweight='bold', y=1.01)
plt.tight_layout()
plt.savefig(OUT + r'\fig1_typical_day.png', bbox_inches='tight', dpi=150)
plt.close()
print('fig1 done')

# 图2:全年负载与光伏热力图（按月×时段）
fig, axes = plt.subplots(1,2, figsize=(14,5))

# 按月均值计算 (12, 144)
load_monthly = np.array([load2[months==m].mean(axis=0) for m in range(1,13)])
pv_monthly   = np.array([pv2[months==m].mean(axis=0) for m in range(1,13)])
month_names  = ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月']

im1 = axes[0].imshow(load_monthly, aspect='auto', cmap='YlGn', origin='upper')
axes[0].set_title('全年负载月均热力图（kW）', fontsize=12, fontweight='bold')
axes[0].set_yticks(range(12)); axes[0].set_yticklabels(month_names, fontsize=9)
axes[0].set_xticks(tick_pos[::2]); axes[0].set_xticklabels(tick_lab[::2], rotation=45, fontsize=7)
axes[0].set_xlabel('时刻', fontsize=10)
plt.colorbar(im1, ax=axes[0], label='kW')

im2 = axes[1].imshow(pv_monthly, aspect='auto', cmap='YlOrRd', origin='upper')
axes[1].set_title('全年光伏月均热力图（kW）', fontsize=12, fontweight='bold')
axes[1].set_yticks(range(12)); axes[1].set_yticklabels(month_names, fontsize=9)
axes[1].set_xticks(tick_pos[::2]); axes[1].set_xticklabels(tick_lab[::2], rotation=45, fontsize=7)
axes[1].set_xlabel('时刻', fontsize=10)
plt.colorbar(im2, ax=axes[1], label='kW')

plt.suptitle('全年负载与光伏发电实际功率月均分布热力图', fontsize=13, fontweight='bold')
plt.tight_layout()
plt.savefig(OUT + r'\fig2_annual_heatmap.png', bbox_inches='tight', dpi=150)
plt.close()
print('fig2 done')

# 图3: 光伏预报精度分析（逐日 vs 实际 + 四季误差箱线图）
df3_0 = df3[df3.iloc[:,1]=='0:00'].reset_index(drop=True)
pv_fc_24  = df3_0.iloc[:,2:26].values.astype(float)  # (365,24)
pv_actual_sum = pv2.sum(axis=1) / 6   # kWh/day
pv_fc_sum     = pv_fc_24.sum(axis=1)  # 近似kWh/day

fig, axes = plt.subplots(1,2, figsize=(14,5))

# 左图: 逐日六边形分箱图
ax = axes[0]
hb = ax.hexbin(pv_fc_sum, pv_actual_sum, gridsize=28, mincnt=1, cmap='Blues', linewidths=0.3, edgecolors='white', alpha=0.88)
mn = min(pv_fc_sum.min(), pv_actual_sum.min())
mx = max(pv_fc_sum.max(), pv_actual_sum.max())
ax.plot([mn, mx], [mn, mx], color='#B85C5C', ls='--', lw=1.5, label='理想1:1线')
corr = np.corrcoef(pv_fc_sum, pv_actual_sum)[0,1]
rmse = np.sqrt(((pv_fc_sum - pv_actual_sum)**2).mean())
ax.set_xlim(mn, mx)
ax.set_ylim(mn, mx)
ax.set_aspect('equal', adjustable='box')
ax.set_xlabel('日前预报总发电量（kWh）', fontsize=11)
ax.set_ylabel('实际总发电量（kWh）', fontsize=11)
ax.set_title(f'光伏日前预报 vs 实际\n(R={corr:.3f}, RMSE={rmse:.0f} kWh)', fontsize=11, fontweight='bold')
cbar = fig.colorbar(hb, ax=ax, pad=0.02)
cbar.set_label('逐日数据密度', fontsize=9)
ax.legend(fontsize=9, loc='upper left')
ax.grid(alpha=0.25)

# 右图: 按季节的误差箱线图
season_map = {1:'冬',2:'冬',3:'春',4:'春',5:'春',6:'夏',7:'夏',8:'夏',9:'秋',10:'秋',11:'秋',12:'冬'}
seasons    = [season_map[m] for m in months]
errors     = pv_actual_sum - pv_fc_sum
season_order = ['春','夏','秋','冬']
season_errors = [errors[[s==ss for s in seasons]] for ss in season_order]
bp = axes[1].boxplot(season_errors, labels=season_order, patch_artist=True,
                     medianprops=dict(color='black',lw=2))
colors = ['#2ecc71','#f39c12','#B22222','#3498db']
for patch, c in zip(bp['boxes'], colors):
    patch.set_facecolor(c); patch.set_alpha(0.7)
axes[1].axhline(0, color='red', ls='--', lw=1.2)
axes[1].set_title('各季节日前预报误差分布（实际 - 预报 kWh）', fontsize=11, fontweight='bold')
axes[1].set_ylabel('预报误差（kWh）', fontsize=11)
axes[1].set_xlabel('季节', fontsize=11)
axes[1].grid(alpha=0.3, axis='y')

plt.suptitle('光伏发电日前预报精度综合评估', fontsize=13, fontweight='bold')
plt.tight_layout()
plt.savefig(OUT + r'\fig3_pv_forecast_accuracy.png', bbox_inches='tight', dpi=150)
plt.close()
print('fig3 done')

# 图4: 附件4 电价分布特征（直方图+四季均值+月均日曲线）
fig = plt.figure(figsize=(14,5))
gs  = gridspec.GridSpec(1,2, figure=fig, wspace=0.35)
ax1 = fig.add_subplot(gs[0,0])
ax2 = fig.add_subplot(gs[0,1])

flat_p = prices4.flatten()
ax1.hist(flat_p, bins=80, color='#4fc3f7', alpha=0.7, edgecolor='white', lw=0.3)
ax1.axvline(flat_p.mean(), color='red', ls='--', lw=1.5, label=f'均值 {flat_p.mean():.3f}')
ax1.axvline(np.median(flat_p), color='orange', ls='-.', lw=1.5, label=f'中位数 {np.median(flat_p):.3f}')
ax1.set_xlabel('电价（元/kWh）', fontsize=11); ax1.set_ylabel('频次', fontsize=11)
ax1.set_title('全年实时电价频率分布', fontsize=11, fontweight='bold')
ax1.legend(fontsize=9); ax1.grid(alpha=0.3)

# 四季典型日曲线
season_days = {'春(3-20)':78, '夏(6-21)':171, '秋(9-23)':265, '冬(12-21)':354}
colors2     = ['#2ecc71','#FFD700','#e74c3c','#3498db']
for (label, di), color in zip(season_days.items(), colors2):
    if di < len(prices4):
        ax2.plot(np.arange(144), prices4[di], lw=1.8, color=color, label=label, alpha=0.85)
ax2.set_xticks(tick_pos[::2]); ax2.set_xticklabels(tick_lab[::2], rotation=45, fontsize=8)
ax2.set_xlabel('时刻', fontsize=11); ax2.set_ylabel('电价（元/kWh）', fontsize=11)
ax2.set_title('四季典型日实时电价曲线（附件4）', fontsize=11, fontweight='bold')
ax2.legend(fontsize=9); ax2.grid(alpha=0.3)

plt.suptitle('全年波动电价统计特征与季节规律', fontsize=13, fontweight='bold')
plt.savefig(OUT + r'\fig4_price_stats.png', bbox_inches='tight', dpi=150)
plt.close()
print('fig4 done')

# 图5: 全年日负载与光伏总量时序图（数据完整性可视化）
load_daily = load2.sum(axis=1)/6
pv_daily = pv2.sum(axis=1)/6
net_load = load_daily - pv_daily
x_days = np.arange(365)
m_ticks = [dates[dates.dt.month==m].index[0] if len(dates[dates.dt.month==m])>0 else 0 for m in range(1,13)]

# 找每月第一天索引
month_start_idx = []
for m in range(1,13):
    idx = np.where(months==m)[0]
    if len(idx)>0: month_start_idx.append(idx[0])

month_labels = ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月']

# 创建图形
fig, axes = plt.subplots(2,1, figsize=(13,7), sharex=True)

# 上图：全年逐日负载与光伏
axes[0].bar(x_days, load_daily/1000, color='#5B7C99', alpha=0.62, width=1.0, label='日负载总量')
axes[0].bar(x_days, pv_daily/1000, color='#D6A84F', alpha=0.68, width=1.0, label='日光伏总量')

# 添加月份分界线
for idx in month_start_idx: axes[0].axvline(idx, color='#888888', ls=':', lw=0.6, alpha=0.25)

axes[0].set_ylabel('电量（MWh）', fontsize=11)
axes[0].set_title('全年逐日负载与光伏发电总量', fontsize=11, fontweight='bold')
axes[0].legend(fontsize=9, frameon=True, framealpha=0.9)
axes[0].grid(alpha=0.25, axis='y')
axes[0].spines['top'].set_visible(False)
axes[0].spines['right'].set_visible(False)

# =========================
# 下图：全年逐日净负载
# =========================
axes[1].fill_between(x_days, net_load/1000, color='#9A7064', alpha=0.38, label='净负荷（负载−光伏）')
axes[1].axhline(net_load.mean()/1000, color='#666666', ls='--', lw=1.4, label=f'年均 {net_load.mean()/1000:.1f} MWh/天')

# 添加月份分界线
for idx in month_start_idx: axes[1].axvline(idx, color='#888888', ls=':', lw=0.6, alpha=0.25)

axes[1].set_ylabel('净负荷（MWh）', fontsize=11)
axes[1].set_title('全年逐日净负荷变化特征', fontsize=11, fontweight='bold')
axes[1].legend(fontsize=9, frameon=True, framealpha=0.9)
axes[1].grid(alpha=0.25, axis='y')
axes[1].spines['top'].set_visible(False)
axes[1].spines['right'].set_visible(False)

# 标记全年最大净负荷日
net_peak_idx = np.argmax(net_load)
net_peak_val = net_load[net_peak_idx]/1000
axes[1].annotate(f'最大净负荷\n{net_peak_val:.1f} MWh', xy=(net_peak_idx, net_peak_val), xytext=(net_peak_idx+10, net_peak_val+6), fontsize=8.5, color='#76564D', arrowprops=dict(arrowstyle='->', color='#666666', lw=0.8), bbox=dict(boxstyle='round,pad=0.25', facecolor='white', edgecolor='#CBB8B2', alpha=0.9))

# 设置横坐标
axes[1].set_xlabel('月份', fontsize=11)
axes[1].set_xticks(month_start_idx)
axes[1].set_xticklabels(month_labels, fontsize=9)

# 总标题
plt.suptitle('全年负荷—光伏时序特征与净负载变化', fontsize=13, fontweight='bold')

plt.tight_layout()
plt.savefig(OUT + r'\fig5_annual_timeseries.png', bbox_inches='tight', dpi=300)
plt.close()

print('fig5 done')

# 图6: 数据质量汇总 + 附件3预报时刻对比
fig, axes = plt.subplots(1,2, figsize=(14,5))

# ==================== 左图：月度负荷、光伏与电价 ====================
months_arr = np.arange(1,13)
price_m = [prices4[months==m].mean() for m in range(1,13)]
load_m_avg = [load2[months==m].mean() for m in range(1,13)]
pv_m_avg = [pv2[months==m].mean() for m in range(1,13)]

ax = axes[0]
ax2b = ax.twinx()

bars = ax.bar(months_arr-0.2, load_m_avg, width=0.35, color='#4C6A85', alpha=0.72, label='月均负载（kW）')
bars2 = ax.bar(months_arr+0.2, pv_m_avg, width=0.35, color='#C39A4B', alpha=0.72, label='月均光伏（kW）')
ln = ax2b.plot(months_arr, price_m, color='#8C5A5A', marker='o', lw=2.0, ms=4.5, label='月均电价（元/kWh）')

ax.set_xlabel('月份', fontsize=11)
ax.set_ylabel('功率（kW）', fontsize=11)
ax2b.set_ylabel('电价（元/kWh）', fontsize=11, color='#8C5A5A')
ax2b.tick_params(axis='y', colors='#8C5A5A')
ax.set_title('各月平均负荷、光伏功率与实时电价特征', fontsize=11.5, fontweight='bold')
ax.set_xticks(months_arr)
ax.set_xticklabels([f'{m}月' for m in range(1,13)], fontsize=9)

handles = [bars, bars2] + ln
labels = ['月均负荷（kW）','月均光伏（kW）','月均电价（元/kWh）']
ax.legend(handles, labels, fontsize=8.5, loc='upper left', frameon=True, framealpha=0.9)

ax.grid(alpha=0.22, axis='y')
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax2b.spines['top'].set_visible(False)

# ==================== 右图：不同预报时刻 MAE ====================
forecast_times = ['0:00','6:00','12:00','18:00']
maes = []

for ft in forecast_times:
    df3_t = df3[df3.iloc[:,1]==ft].reset_index(drop=True)
    fc = df3_t.iloc[:,2:26].values.astype(float)
    n = min(len(fc), len(pv_actual_sum))
    fc_sum = fc[:n].sum(axis=1)
    mae = np.abs(fc_sum - pv_actual_sum[:n]).mean()
    maes.append(mae)
    print(f'预报时刻{ft} MAE={mae:.0f} kWh')

ax = axes[1]
y = np.arange(len(forecast_times))

bars3 = ax.barh(y, maes, height=0.48, color='#718096', alpha=0.72, edgecolor='#4A5568', linewidth=0.7)

ax.set_yticks(y)
ax.set_yticklabels(forecast_times, fontsize=10)
ax.invert_yaxis()
ax.set_xlabel('日总电量预报MAE（kWh）', fontsize=11)
ax.set_ylabel('日前预报发布时刻', fontsize=11)
ax.set_title('不同预报时刻的光伏日总电量预报精度', fontsize=11.5, fontweight='bold')

ax.grid(alpha=0.22, axis='x')
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

for bar, mae in zip(bars3, maes):
    ax.text(bar.get_width()+max(maes)*0.015, bar.get_y()+bar.get_height()/2, f'{mae:.0f}', va='center', fontsize=9.5, color='#374151')

plt.suptitle('月度运行特征与光伏预报精度综合分析', fontsize=13.5, fontweight='bold')

line = Line2D([0.523, 0.523], [0.08, 0.91], transform=fig.transFigure, color='#B0B0B0', linewidth=0.8, alpha=0.7)
fig.add_artist(line)

plt.tight_layout(rect=[0,0,1,0.94])
plt.savefig(OUT + r'\fig6_data_quality_summary.png', bbox_inches='tight', dpi=300)
plt.close()

print('fig6 done')

# 输出统计表格数据到CSV
# 表1: 四份附件基本统计
summary = {
    '附件': ['附件1（典型日）','附件2（全年负载）','附件2（全年光伏）','附件3（光伏预报）','附件4（实时电价）'],
    '维度': ['144时段×1天','144时段×365天','144时段×365天','4预报时刻×365天','144时段×365天'],
    '均值': [f'{load1.mean():.1f} kW', f'{load2.mean():.1f} kW', f'{pv2.mean():.1f} kW',
             f'{pv_fc_24.mean():.1f} kW', f'{prices4.mean():.4f} 元/kWh'],
    '最小值': [f'{load1.min():.1f}', f'{load2.min():.1f}', f'{pv2.min():.1f}',
               f'{pv_fc_24.min():.1f}', f'{prices4.min():.4f}'],
    '最大值': [f'{load1.max():.1f}', f'{load2.max():.1f}', f'{pv2.max():.1f}',
               f'{pv_fc_24.max():.1f}', f'{prices4.max():.4f}'],
    '缺失值': [0, 0, 0, 0, 0]
}
pd.DataFrame(summary).to_csv(OUT + r'\table1_data_summary.csv', index=False, encoding='utf-8-sig')

# 表2: 月均数据统计
month_df = pd.DataFrame({
    '月份': [f'{m}月' for m in range(1,13)],
    '月均日负载(kWh)': [f'{load2[months==m].sum(axis=1).mean()/6:.0f}' for m in range(1,13)],
    '月均日光伏(kWh)': [f'{pv2[months==m].sum(axis=1).mean()/6:.0f}' for m in range(1,13)],
    '月均电价(元/kWh)': [f'{prices4[months==m].mean():.4f}' for m in range(1,13)],
    '月均净负载(kWh)': [f'{(load2[months==m].sum(axis=1)-pv2[months==m].sum(axis=1)).mean()/6:.0f}' for m in range(1,13)]
})
month_df.to_csv(OUT + r'\table2_monthly_stats.csv', index=False, encoding='utf-8-sig')
print('\n=== 统计摘要 ===')
print(month_df.to_string(index=False))

# 表3: 预报精度
acc_df = pd.DataFrame({
    '预报时刻': forecast_times,
    'MAE(kWh)': [f'{m:.0f}' for m in maes],
    'RMSE(kWh)': [f'{np.sqrt(((df3[df3.iloc[:,1]==ft].iloc[:365,2:26].values.astype(float).sum(axis=1)-pv_actual_sum)**2).mean()):.0f}' for ft in forecast_times],
    '相关系数R': [f'{np.corrcoef(df3[df3.iloc[:,1]==ft].iloc[:365,2:26].values.astype(float).sum(axis=1), pv_actual_sum)[0,1]:.4f}' for ft in forecast_times]
})
acc_df.to_csv(OUT + r'\table3_forecast_accuracy.csv', index=False, encoding='utf-8-sig')
print(acc_df.to_string(index=False))

print('\n所有图片和CSV已保存到:', OUT)
