#Q3 可视化脚本 v2 — 加入无调整对照组，重绘全部6张图
import os, re
import numpy as np
import pandas as pd
import openpyxl
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.lines import Line2D
from datetime import datetime, timedelta
import matplotlib.dates as mdates

plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
OUT  = os.path.join(BASE, 'output')
os.makedirs(OUT, exist_ok=True)

# 读取数据
def load_sheet(path, sheet):
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    rows = list(wb[sheet].iter_rows(values_only=True))
    wb.close()
    return rows

def parse_date(raw):
    if raw is None:
        return None
    if hasattr(raw, 'year'):
        return pd.Timestamp(raw)
    s = str(raw).strip()
    nums = re.findall(r'\d+', s)
    if len(nums) >= 3:
        return pd.Timestamp(int(nums[0]), int(nums[1]), int(nums[2]))
    return None

def sheet_to_df(rows):
    h = rows[0]
    fc = h.index('全天购电费')
    slot_cols = slice(1, 145)      
    data = []
    for r in rows[1:]:
        dt = parse_date(r[0])
        if dt is None:
            continue
        cost = r[fc] or 0.0
        slots = [v or 0.0 for v in r[slot_cols]]
        data.append({'date': dt, 'cost': float(cost), 'slots': np.array(slots, dtype=float)})
    return data

print("加载数据 ...")
R3_PATH = os.path.join(ROOT, 'results/result3.xlsx')
RN_PATH = os.path.join(ROOT, 'results/result3_no_adjust.xlsx')

rows_p  = load_sheet(R3_PATH, '计划购电量')
rows_a  = load_sheet(R3_PATH, '调整购电量')
rows_n  = load_sheet(RN_PATH, '调整购电量')

dp = sheet_to_df(rows_p)  
da = sheet_to_df(rows_a)   
dn = sheet_to_df(rows_n)   

# 按日期对齐
date_p = {d['date']: d for d in dp}
date_a = {d['date']: d for d in da}
date_n = {d['date']: d for d in dn}

dates_sorted = sorted(date_a.keys())

# 电价
raw1 = pd.read_excel(os.path.join(ROOT, '附件/附件1.xlsx'), header=0)
price = raw1.iloc[:144, 1].astype(float).values

# 轴刻度
x144  = np.arange(144)
x_pos = [t*6 for t in range(0, 24, 4)]
x_lbl = [f'{h}:00' for h in range(0, 24, 4)]
MONTHS = list(range(2, 13))
MONTH_LABELS = [f'{m}月' for m in MONTHS]

# 月度汇总
mon_p = defaultdict(float); mon_a = defaultdict(float); mon_n = defaultdict(float)
for dt in dates_sorted:
    m = dt.month
    mon_p[m] += date_p.get(dt, {}).get('cost', 0)
    mon_a[m] += date_a.get(dt, {}).get('cost', 0)
    mon_n[m] += date_n.get(dt, {}).get('cost', 0)

m_p  = [mon_p[m]/10000 for m in MONTHS]
m_a  = [mon_a[m]/10000 for m in MONTHS]
m_n  = [mon_n[m]/10000 for m in MONTHS]

TOTAL_P = sum(mon_p.values()) / 10000
TOTAL_A = sum(mon_a.values()) / 10000
TOTAL_N = sum(mon_n.values()) / 10000
DAY_A   = TOTAL_A * 10000 / len(dates_sorted)
DAY_N   = TOTAL_N * 10000 / len(dates_sorted)

print(f"  计划: {TOTAL_P:.2f}万  四阶段调整: {TOTAL_A:.2f}万  无调整: {TOTAL_N:.2f}万")
print(f"  日均 调整: {DAY_A:.2f}元  无调整: {DAY_N:.2f}元  节省: {DAY_N-DAY_A:.2f}元/天")

# 图1：月度三方案费用对比（计划/四阶段调整/无调整）
print("生成 fig1_monthly_plan_vs_adj.png ...")
fig, ax = plt.subplots(figsize=(14, 6))
x = np.arange(len(MONTHS))
ax.plot(x, m_p, color='#1565C0', lw=1.5, marker='o', markersize=5,
        label=f'0:00计划（{TOTAL_P:.2f}万元）', alpha=0.9)
ax.plot(x, m_a, color='#E65100', lw=1.8, marker='s', markersize=5,
        label=f'四阶段调整（{TOTAL_A:.2f}万元）', alpha=0.9)
ax.plot(x, m_n, color='#388E3C', lw=1.5, marker='^', markersize=5,
        label=f'无调整对照（{TOTAL_N:.2f}万元）', alpha=0.9)
ax.set_xticks(x); ax.set_xticklabels(MONTH_LABELS, fontsize=10)
ax.set_xlabel('月份', fontsize=11); ax.set_ylabel('月度购电费用（万元）', fontsize=11)
ax.set_title('Q3方案各月购电费用三方案对比', fontsize=13)
ax.legend(fontsize=9); ax.grid(axis='y', alpha=0.3)
save_val = TOTAL_N - TOTAL_A
ax.text(0.01, 0.98,
        f'四阶段调整 vs 无调整：节省 {save_val:.2f}万元（{save_val/TOTAL_N*100:.2f}%）\n'
        f'日均节省 {(DAY_N-DAY_A):.0f}元/天',
        transform=ax.transAxes, fontsize=10, va='top',
        bbox=dict(boxstyle='round', facecolor='#E8F5E9', alpha=0.9))
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig1_monthly_plan_vs_adj.png'), dpi=150, bbox_inches='tight')
plt.close()
print("  完成 fig1")

# 图2：四季典型日调度对比（计划 vs 调整 vs 无调整）
print("生成 fig2_seasonal_dispatch.png ...")
season_days = [('春分(3-20)', '2025-03-20'), ('夏至(6-21)', '2025-06-21'),
               ('秋分(9-23)', '2025-09-23'), ('冬至(12-21)', '2025-12-21')]
fig2, axes2 = plt.subplots(2, 2, figsize=(15, 9))
for idx, (title, ds) in enumerate(season_days):
    ax = axes2[idx//2][idx%2]
    dt = pd.Timestamp(ds)
    dp_day = date_p.get(dt)
    da_day = date_a.get(dt)
    dn_day = date_n.get(dt)
    if dp_day and da_day and dn_day:
        ax.plot(x144, dp_day['slots'], color='#1565C0', lw=1.5, label='0:00计划', alpha=0.9)
        ax.plot(x144, da_day['slots'], color='#E65100', lw=1.8, ls='--', label='四阶段调整', alpha=0.9)
        ax.plot(x144, dn_day['slots'], color='#388E3C', lw=1.5, ls=':', label='无调整对照', alpha=0.9)
        cp = dp_day['cost']; ca = da_day['cost']; cn = dn_day['cost']
        ax.set_title(f'{title}\n计划{cp:.0f}元 | 调整{ca:.0f}元 | 无调{cn:.0f}元\n'
                     f'调整节省 {cn-ca:.0f}元 vs 无调', fontsize=9)
    ax.set_xticks(x_pos); ax.set_xticklabels(x_lbl, fontsize=8)
    ax.set_xlabel('时刻', fontsize=9); ax.set_ylabel('购电量（kWh）', fontsize=9)
    ax.legend(fontsize=8); ax.grid(axis='y', alpha=0.25)
fig2.suptitle('Q3方案四季典型日购电量对比（0:00计划 / 四阶段调整 / 无调整）', fontsize=13, fontweight='bold')
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig2_seasonal_dispatch.png'), dpi=150, bbox_inches='tight')
plt.close()
print("  完成 fig2")

# 图3：全年逐日费用时序（调整 vs 无调整）
print("生成 fig3_daily_plan_vs_adj.png ...")
daily_a = pd.Series({dt: date_a[dt]['cost']/10000 for dt in dates_sorted})
daily_n = pd.Series({dt: date_n[dt]['cost']/10000 for dt in dates_sorted})
daily_diff = daily_n - daily_a   

fig3, (ax3a, ax3b) = plt.subplots(2, 1, figsize=(15, 8), sharex=True,
                                   gridspec_kw={'height_ratios': [3, 1]})
ax3a.plot(daily_a.index, daily_a.values, color='#E65100', lw=0.9, label=f'四阶段调整（{TOTAL_A:.2f}万元）')
ax3a.plot(daily_n.index, daily_n.values, color='#388E3C', lw=0.9, label=f'无调整对照（{TOTAL_N:.2f}万元）', alpha=0.7)
ax3a.set_ylabel('当日购电费（万元）', fontsize=11)
ax3a.set_title('Q3方案全年逐日购电费用：四阶段调整 vs 无调整对照', fontsize=13)
ax3a.legend(fontsize=10); ax3a.grid(axis='y', alpha=0.3)
better_days = (daily_diff > 0).sum()
ax3a.text(0.01, 0.97,
          f'调整优于无调整天数：{better_days}/{len(dates_sorted)}天\n'
          f'全年节省：{(TOTAL_N-TOTAL_A):.2f}万元',
          transform=ax3a.transAxes, fontsize=9, va='top',
          bbox=dict(boxstyle='round', facecolor='#E8F5E9', alpha=0.85))
ax3b.bar(daily_diff.index, daily_diff.values,
         color=np.where(daily_diff.values >= 0, '#E65100', '#388E3C'), alpha=0.7, width=1)
ax3b.axhline(0, color='k', lw=0.8)
ax3b.set_ylabel('节省（万元）', fontsize=10)
ax3b.set_xlabel('日期', fontsize=11)
ax3b.set_title('逐日节省金额（正值=四阶段调整更优）', fontsize=10)
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig3_daily_plan_vs_adj.png'), dpi=150, bbox_inches='tight')
plt.close()
print("  完成 fig3")

#  图4：调整效益分布（无调整-调整 差值直方图，按季节分）
print("生成 fig4_adj_distribution.png ...")
diff_vals = np.array([date_n[dt]['cost'] - date_a[dt]['cost'] for dt in dates_sorted])

season_map_m = {2:'春',3:'春',4:'春',5:'夏',6:'夏',7:'夏',8:'夏',
                9:'秋',10:'秋',11:'秋',12:'冬',1:'冬'}
season_arr = np.array([season_map_m[dt.month] for dt in dates_sorted])

fig4, axes4 = plt.subplots(1, 2, figsize=(13, 5))

x_all = np.arange(len(diff_vals))
axes4[0].plot(x_all, diff_vals, color='#E65100', lw=1.0, alpha=0.8)
axes4[0].axhline(diff_vals.mean(), color='red', lw=1.5, ls='--',
                 label=f'均值 {diff_vals.mean():.0f}元')
axes4[0].axhline(0, color='k', lw=1)
axes4[0].set_xlabel('日期序号', fontsize=10)
axes4[0].set_ylabel('无调整 - 四阶段调整 费用差（元）', fontsize=10)
axes4[0].set_title('全年逐日调整效益\n（正值=四阶段调整更优）', fontsize=11)
axes4[0].legend(fontsize=9)
pct_better = (diff_vals > 0).mean() * 100
axes4[0].text(0.98, 0.97, f'调整更优：{pct_better:.1f}%天',
              transform=axes4[0].transAxes, ha='right', va='top', fontsize=9,
              bbox=dict(boxstyle='round', facecolor='#E8F5E9', alpha=0.85))

for s, c in [('春','#4CAF50'),('夏','#FF5722'),('秋','#FF9800'),('冬','#2196F3')]:
    sub = diff_vals[season_arr == s]
    if len(sub):
        axes4[1].plot(np.arange(len(sub)), sub, color=c, lw=1.0, alpha=0.8,
                      label=f'{s}季(均值{sub.mean():.0f}元)')
axes4[1].axhline(0, color='k', lw=1)
axes4[1].set_xlabel('日内序号', fontsize=10)
axes4[1].set_ylabel('无调整 - 四阶段调整 费用差（元）', fontsize=10)
axes4[1].set_title('四季调整效益', fontsize=12)
axes4[1].legend(fontsize=9)

plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig4_adj_distribution.png'), dpi=150, bbox_inches='tight')
plt.close()
print("  完成 fig4")

# 图5：冬季典型日详细对比（计划/调整/无调整 + 电价）
print("生成 fig5_winter_detail.png ...")
winter_dt = pd.Timestamp('2025-12-21')
dp5 = date_p.get(winter_dt); da5 = date_a.get(winter_dt); dn5 = date_n.get(winter_dt)
fig5, (ax5a, ax5b) = plt.subplots(2, 1, figsize=(13, 8), sharex=True,
                                   gridspec_kw={'height_ratios': [3, 1]})
if dp5 and da5 and dn5:
    ax5a.step(x144, dp5['slots'], where='mid', color='#1565C0', lw=2, label=f"0:00计划 {dp5['cost']:.0f}元")
    ax5a.step(x144, da5['slots'], where='mid', color='#E65100', lw=2, ls='--', label=f"四阶段调整 {da5['cost']:.0f}元")
    ax5a.step(x144, dn5['slots'], where='mid', color='#388E3C', lw=1.5, ls=':', label=f"无调整 {dn5['cost']:.0f}元")
    ax5r = ax5a.twinx()
    ax5r.plot(x144, price, color='#888', lw=1.2, alpha=0.55, label='电价')
    ax5r.set_ylabel('电价（元/kWh）', fontsize=9, color='#888')
    ax5r.tick_params(axis='y', labelcolor='#888', labelsize=8)
    delta5 = da5['slots'] - dn5['slots']
    ax5b.bar(x144, delta5, color=np.where(delta5 >= 0, '#E65100', '#388E3C'), alpha=0.8, width=0.8)
    ax5b.axhline(0, color='k', lw=0.8)
    ax5b.set_ylabel('调整增量（kWh）', fontsize=10)
    ax5b.set_title('四阶段调整购电量 - 无调整购电量（正值=调整增加购电）', fontsize=9)
ax5a.set_title(f'冬至（12月21日）详细调度对比\n调整节省 {dn5["cost"]-da5["cost"]:.0f}元 vs 无调整', fontsize=12)
ax5a.set_ylabel('购电量（kWh）', fontsize=10)
ax5a.legend(fontsize=9, loc='upper left'); ax5a.grid(axis='y', alpha=0.3)
ax5b.set_xticks(x_pos); ax5b.set_xticklabels(x_lbl, fontsize=9)
ax5b.set_xlabel('时刻', fontsize=10)
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig5_winter_detail.png'), dpi=150, bbox_inches='tight')
plt.close()
print("  完成 fig5")

# 图6：综合汇总（年总费用柱状 + 季节箱线）
print("生成 fig6_summary.png ...")

fig_3d = plt.figure(figsize=(10, 7))
ax6l = fig_3d.add_subplot(111, projection='3d')

lbls = ['0:00计划\n(名义)', '四阶段调整\n(实际)', '无调整对照\n(实际)']
vals6 = [TOTAL_P, TOTAL_A, TOTAL_N]
clrs6 = ['#8FB3D9', '#D9A6A6', '#A8C5A0']

x = np.arange(len(vals6))
y = np.zeros(len(vals6))
z = np.zeros(len(vals6))
dx = np.full(len(vals6), 0.55)
dy = np.full(len(vals6), 0.55)
dz = np.array(vals6)

for i in range(len(vals6)):
    ax6l.bar3d(
        x[i], y[i], z[i], dx[i], dy[i], dz[i],
        color=clrs6[i], alpha=0.45,
        edgecolor='#555555', linewidth=0.7, shade=False
    )

line_y = np.full(len(vals6), -0.12)
line_x = x + dx / 2
line_z = np.array(vals6)

ax6l.plot(
    line_x, line_y, line_z,
    color='#5B4B8A', linewidth=2.2,
    marker='o', markersize=7,
    markerfacecolor='#5B4B8A', markeredgecolor='white', markeredgewidth=1.0, zorder=10
)

for i, val in enumerate(vals6):
    ax6l.text(
        line_x[i], -0.32, 20,
        f'{val:.2f}万元',
        ha='center', va='bottom',
        fontsize=10.5, fontweight='bold', color='#333333'
    )

ax6l.set_xticks(line_x)
ax6l.set_xticklabels(lbls, fontsize=10)
ax6l.set_xlabel('方案', fontsize=11, labelpad=10)
ax6l.set_yticks([])
ax6l.set_ylabel('')
ax6l.set_zlabel('年购电费用（万元）', fontsize=11, labelpad=10)
ax6l.set_zlim(0, max(vals6) * 1.18)
ax6l.set_title('Q3方案三方案年总费用对比', fontsize=13, fontweight='bold', pad=20)

save_abs = TOTAL_N - TOTAL_A
ax6l.text2D(
    0.50, 0.93,
    f'四阶段调整比无调整节省 {save_abs:.2f}万元\n'
    f'日均节省 {(DAY_N - DAY_A):.0f}元',
    transform=ax6l.transAxes, ha='center', va='center',
    fontsize=10, color='#8B1E1E',
    bbox=dict(boxstyle='round,pad=0.5', facecolor='#F7F4EA', edgecolor='#666666', linewidth=0.8, alpha=0.92)
)

ax6l.view_init(elev=22, azim=-60)
ax6l.set_box_aspect((4.5, 1.5, 5))
ax6l.grid(True, linestyle='--', linewidth=0.6, alpha=0.22)
plt.tight_layout()

from io import BytesIO
buf = BytesIO()
plt.savefig(buf, format='png', dpi=300, bbox_inches='tight')
buf.seek(0)
plt.close(fig_3d)

fig6, axes6 = plt.subplots(1, 2, figsize=(16, 7))

img = plt.imread(buf)
axes6[0].imshow(img)
axes6[0].axis('off') 
buf.close()

# 绘制右侧的小提琴图
season_order = ['春', '夏', '秋', '冬']
violin_data = [diff_vals[season_arr == s] for s in season_order]
vp = axes6[1].violinplot(violin_data, positions=range(1, len(season_order) + 1), showmeans=True, showmedians=True)
colors_violin = ['#4CAF50', '#FF5722', '#FF9800', '#2196F3']
for pc, color in zip(vp['bodies'], colors_violin):
    pc.set_facecolor(color)
    pc.set_alpha(0.5)
    pc.set_edgecolor('black')
for key in ['cmeans', 'cmedians', 'cbars', 'cmins', 'cmaxes']:
    if key in vp:
        vp[key].set_color('black')
        vp[key].set_linewidth(1.2)

axes6[1].set_xticks(range(1, len(season_order) + 1))
axes6[1].set_xticklabels(season_order)
axes6[1].axhline(0, color='k', lw=0.8, linestyle='--')
axes6[1].set_xlabel('季节', fontsize=11)
axes6[1].set_ylabel('节省金额（元）', fontsize=11)
axes6[1].set_title('各季节四阶段调整效益小提琴图\n（正值=调整更优）', fontsize=11)
axes6[1].grid(axis='y', alpha=0.3)

plt.suptitle('Q3方案综合汇总', fontsize=16, fontweight='bold', y=0.98)
plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.savefig(os.path.join(OUT, 'fig6_summary.png'), dpi=300, bbox_inches='tight')
plt.close(fig6)

print("  完成 fig6")

# 图7：四季典型日经济性雷达图
print("生成 fig7_seasonal_radar.png ...")

season_names = ['春分', '夏至', '秋分', '冬至']
plan_cost = np.array([42258.46, 21715.25, 43275.91, 60259.02])
adj_cost = np.array([60019.27, 30389.37, 58560.22, 82966.50])
increase = np.array([42.03, 39.94, 35.32, 37.68])

# 学术型低饱和配色
c_plan = '#4C78A8'
c_adj = '#7A7A7A'
c_inc = '#9C755F'
c_grid = '#D0D0D0'
c_text = '#333333'

plan_norm = plan_cost / plan_cost.max()
adj_norm = adj_cost / adj_cost.max()

angles = np.linspace(0, 2*np.pi, len(season_names), endpoint=False).tolist()
angles += angles[:1]
plan_r = np.r_[plan_norm, plan_norm[0]]
adj_r = np.r_[adj_norm, adj_norm[0]]

fig = plt.figure(figsize=(13, 6))
ax = fig.add_subplot(121, polar=True)

ax.plot(angles, plan_r, color=c_plan, lw=2.0, marker='o', markersize=5, label='0:00计划')
ax.fill(angles, plan_r, color=c_plan, alpha=0.08)
ax.plot(angles, adj_r, color=c_adj, lw=2.0, marker='s', markersize=5, label='四阶段调整')
ax.fill(angles, adj_r, color=c_adj, alpha=0.10)

ax.set_xticks(angles[:-1])
ax.set_xticklabels(season_names, fontsize=10, color=c_text)
ax.set_ylim(0, 1.05)
ax.set_yticks([0.25, 0.50, 0.75, 1.00])
ax.set_yticklabels(['25%', '50%', '75%', '100%'], fontsize=8, color='#777777')
ax.set_title('四季典型日购电费用相对水平', fontsize=12, fontweight='bold', pad=18)
ax.legend(loc='upper right', bbox_to_anchor=(1.20, 1.12), fontsize=9, frameon=False)
ax.grid(color=c_grid, alpha=0.65, linestyle='--', linewidth=0.7)
ax.spines['polar'].set_color('#B5B5B5')
ax.spines['polar'].set_linewidth(0.8)

for i, (p, a) in enumerate(zip(plan_cost, adj_cost)):
    ax.text(angles[i], plan_norm[i] + 0.07, f'{p/10000:.2f}万', ha='center', va='center', fontsize=8, color=c_plan)
    ax.text(angles[i], adj_norm[i] - 0.07, f'{a/10000:.2f}万', ha='center', va='center', fontsize=8, color='#555555')

# 右侧：调整费用增幅
ax2 = fig.add_subplot(122)
bars = ax2.bar(season_names, increase, width=0.55, color=c_inc, alpha=0.78, edgecolor='#795548', linewidth=0.7)

for bar, val in zip(bars, increase):
    ax2.text(bar.get_x() + bar.get_width()/2, val + 0.7, f'{val:.2f}%', ha='center', va='bottom', fontsize=9.5, fontweight='bold', color='#6E5142')

ax2.axhline(increase.mean(), color='#666666', ls='--', lw=1.2, label=f'四季平均 {increase.mean():.2f}%')
ax2.set_xlabel('典型日', fontsize=11, color=c_text)
ax2.set_ylabel('调整后费用相对计划增幅（%）', fontsize=11, color=c_text)
ax2.set_title('四季典型日费用增幅', fontsize=12, fontweight='bold')
ax2.set_ylim(0, max(increase) * 1.18)
ax2.grid(axis='y', color=c_grid, alpha=0.55, linestyle='--', linewidth=0.7)
ax2.spines['top'].set_visible(False)
ax2.spines['right'].set_visible(False)
ax2.spines['left'].set_color('#AAAAAA')
ax2.spines['bottom'].set_color('#AAAAAA')
ax2.legend(fontsize=9, frameon=False, loc='upper right')

plt.suptitle('Q3方案四季典型日经济性特征分析', fontsize=14, fontweight='bold', color=c_text, y=0.98)
plt.tight_layout(rect=[0, 0, 1, 0.94])
plt.savefig(os.path.join(OUT, 'fig7_seasonal_radar.png'), dpi=300, bbox_inches='tight')
plt.close()

print("  完成 fig7")

print(f"\n所有图表生成完毕，输出目录：{OUT}")
