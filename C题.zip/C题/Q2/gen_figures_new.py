#生成问题2两阶段模型论文图片
import sys, numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from pathlib import Path
import warnings
from matplotlib.lines import Line2D
warnings.filterwarnings('ignore')

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))
from data_loader import DataLoader

plt.rcParams['font.family'] = ['SimHei', 'Microsoft YaHei', 'sans-serif']
plt.rcParams['axes.unicode_minus'] = False

ROOT = Path(__file__).parent.parent
OUT  = Path(__file__).parent / 'output'
OUT.mkdir(exist_ok=True)

# 加载数据
loader  = DataLoader(ROOT / '附件')
data2   = loader.load_attachment2()
load_all  = data2['load']
pv_all    = data2['pv_actual']
dates_all = data2['dates']

ann1  = pd.read_excel(ROOT / '附件/附件1.xlsx')
price = ann1['电价'].values  # (144,)

df_pur = pd.read_excel(ROOT / 'results/result2_improved.xlsx', sheet_name=0)
df_pur['date'] = pd.to_datetime(df_pur.iloc[:, 0])
df_chg = pd.read_excel(ROOT / 'results/result2_improved.xlsx', sheet_name=1)
df_emg = pd.read_excel(ROOT / 'results/result2_improved.xlsx', sheet_name=2)

fc     = np.load(ROOT / 'results/forecasts_p2.npz', allow_pickle=True)
pv_fc  = fc['pv_forecast']   # (334,144)
ld_fc  = fc['load_forecast']  # (334,144)

t_hours = np.arange(144) / 6
start   = pd.Timestamp('2025-02-01')

seasons = [
    ('春季 (2025-03-20)', '2025-03-20'),
    ('夏季 (2025-06-21)', '2025-06-21'),
    ('秋季 (2025-09-23)', '2025-09-23'),
    ('冬季 (2025-12-21)', '2025-12-21'),
]
season_colors = ['steelblue', 'orange', 'green', 'red']

# 图1：四季典型日 实测 vs SARIMA预测（负荷+光伏）
fig, axes = plt.subplots(2, 2, figsize=(14, 9))
axs = [axes[0,0], axes[0,1], axes[1,0], axes[1,1]]

for (title, dstr), ax in zip(seasons, axs):
    idx_real = np.where(dates_all == pd.Timestamp(dstr))[0][0]
    idx_fc   = (pd.Timestamp(dstr) - start).days
    load_d  = load_all[idx_real]
    pv_d    = pv_all[idx_real]

    ax.fill_between(t_hours, load_d, alpha=0.18, color='steelblue')
    ax.plot(t_hours, load_d, color='steelblue', lw=1.8, label='实测负荷')
    ax.fill_between(t_hours, pv_d, alpha=0.18, color='orange')
    ax.plot(t_hours, pv_d,   color='orange',   lw=1.8, label='实测光伏')

    if 0 <= idx_fc < len(ld_fc):
        ax.plot(t_hours, ld_fc[idx_fc], '--', color='steelblue', lw=1.0,
                alpha=0.75, label='SARIMA预测负荷')
    if 0 <= idx_fc < len(pv_fc):
        ax.plot(t_hours, pv_fc[idx_fc], '--', color='orange',    lw=1.0,
                alpha=0.75, label='SARIMA预测光伏')

    ax.set_title(title, fontsize=11, fontweight='bold')
    ax.set_xlabel('时间 (h)', fontsize=9)
    ax.set_ylabel('功率 (kW)', fontsize=9)
    ax.set_xlim(0, 24)
    ax.set_xticks(range(0, 25, 4))
    ax.legend(fontsize=7, ncol=2)
    ax.grid(True, alpha=0.3)

fig.suptitle('四季典型日实测与SARIMA预测对比（负荷与光伏）',
             fontsize=13, fontweight='bold', y=1.01)
plt.tight_layout()
plt.savefig(OUT / 'fig1_seasonal_load_pv.png', dpi=150, bbox_inches='tight')
plt.close()
print('fig1 done')

# 图2：全年购电费月度统计（柱+折线）
df_pur['month'] = df_pur['date'].dt.month
monthly_cost = df_pur.groupby('month')['全天购电费'].sum() / 10000
monthly_pur  = df_pur.groupby('month')['全天购电量'].sum() / 10000

fig, ax1 = plt.subplots(figsize=(12, 6))
x = np.arange(len(monthly_cost))
ax1.bar(x, monthly_cost.values, color='steelblue', alpha=0.72)
ax1.set_xlabel('月份', fontsize=11)
ax1.set_ylabel('购电费 (万元)', fontsize=11, color='black')
ax1.tick_params(axis='y', labelcolor='black')
ax1.set_xticks(x)
ax1.set_xticklabels([f'{m}月' for m in monthly_cost.index])
for i, c in enumerate(monthly_cost.values):
    ax1.text(i, c + 0.4, f'{c:.1f}', ha='center', fontsize=8, color='steelblue')

ax2 = ax1.twinx()
ax2.plot(x, monthly_pur.values, 'o-', color='orangered', lw=2, markersize=6)
ax2.set_ylabel('购电量 (万kWh)', fontsize=11, color='black')
ax2.tick_params(axis='y', labelcolor='black')

p1 = Patch(color='steelblue', alpha=0.72, label='月购电费 (万元)')
p2 = plt.Line2D([0],[0], color='orangered', marker='o', lw=2, label='月购电量 (万kWh)')
ax1.legend(handles=[p1, p2], loc='upper left', fontsize=9)
plt.title('全年各月购电费与购电量统计（2025年2-12月）',
          fontsize=12, fontweight='bold')
plt.tight_layout()
plt.savefig(OUT / 'fig2_monthly_cost.png', dpi=150, bbox_inches='tight')
plt.close()
print('fig2 done')


# 图3：四季典型日计划购电策略（含谷时高亮）
fig, axes = plt.subplots(2, 2, figsize=(14, 9))
axs = [axes[0,0], axes[0,1], axes[1,0], axes[1,1]]

for (title, dstr), ax, col in zip(seasons, axs, season_colors):
    row = df_pur[df_pur['date'] == pd.Timestamp(dstr)]
    if row.empty:
        continue
    plan_144 = row.iloc[0, 1:145].values.astype(float)

    ax.bar(t_hours, plan_144, width=1/6*0.9, color=col, alpha=0.65, label='计划购电 (kW)')
    for t in range(144):
        if price[t] < 0.4:
            ax.axvspan(t/6, (t+1)/6, alpha=0.07, color='blue')

    qty  = row['全天购电量'].values[0]
    cost = row['全天购电费'].values[0]
    ax.text(0.98, 0.97,
            f'购电量:{qty/10000:.2f}万kWh\n购电费:{cost/10000:.2f}万元',
            transform=ax.transAxes, va='top', ha='right', fontsize=8,
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.75))

    ax.set_title(title, fontsize=10, fontweight='bold')
    ax.set_xlabel('时间 (h)', fontsize=9)
    ax.set_ylabel('购电功率 (kW)', fontsize=9)
    ax.set_xlim(0, 24)
    ax.set_xticks(range(0, 25, 4))
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)

fig.suptitle('四季典型日计划购电策略（蓝色背景为深谷时段）',
             fontsize=13, fontweight='bold', y=1.01)
plt.tight_layout()
plt.savefig(OUT / 'fig3_seasonal_purchase.png', dpi=150, bbox_inches='tight')
plt.close()
print('fig3 done')

# 图4：全年逐日购电费时序
fig, ax = plt.subplots(figsize=(14, 5))
daily_cost = df_pur['全天购电费'].values / 10000
x = np.arange(len(daily_cost))
ax.fill_between(x, daily_cost, alpha=0.35, color='steelblue')
ax.plot(x, daily_cost, color='steelblue', lw=1)
ax.axhline(daily_cost.mean(), color='red', ls='--', lw=1.5,
           label=f'日均={daily_cost.mean():.2f}万元')

months_vals = df_pur['date'].dt.month.values
boundaries  = [0] + [i for i in range(1, len(months_vals))
                     if months_vals[i] != months_vals[i-1]] + [len(months_vals)]
for b in boundaries[1:-1]:
    ax.axvline(b, color='gray', ls=':', alpha=0.5)
for i in range(len(boundaries)-1):
    mid = (boundaries[i] + boundaries[i+1]) / 2
    ax.text(mid, 0.02, f'{months_vals[boundaries[i]]}月',
            ha='center', va='bottom', fontsize=8, color='gray',
            transform=ax.get_xaxis_transform())

ax.set_xlabel('日期序号（2025年2月—12月）', fontsize=11)
ax.set_ylabel('购电费 (万元/天)', fontsize=11)
ax.set_title('全年逐日购电费时序图（两阶段调度）', fontsize=12, fontweight='bold')
ax.legend(fontsize=9)
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(OUT / 'fig4_daily_cost_series.png', dpi=150, bbox_inches='tight')
plt.close()
print('fig4 done')

# 图5：SARIMA预测误差 + 电价-购电相关性
ann2_load2 = pd.read_excel(ROOT / '附件/附件2.xlsx', sheet_name='小区负载')
ann2_pv2   = pd.read_excel(ROOT / '附件/附件2.xlsx', sheet_name='光伏发电实际功率')
load_all2  = ann2_load2.iloc[:, 1:145].values
pv_all2    = ann2_pv2.iloc[:,  1:145].values
dates_all2 = pd.to_datetime(ann2_load2.iloc[:, 0])

idxs = []
for i in range(334):
    d = start + pd.Timedelta(days=i)
    c = np.where(dates_all2 == d)[0]
    idxs.append(c[0] if len(c) > 0 else None)

valid  = [(i, j) for i, j in enumerate(idxs) if j is not None]
fc_i   = [v[0] for v in valid]
act_i  = [v[1] for v in valid]
load_actual = load_all2[act_i]
pv_actual   = pv_all2[act_i]
load_mae_day = np.abs(ld_fc[fc_i] - load_actual).mean(axis=1)
pv_mae_day   = np.abs(pv_fc[fc_i] - pv_actual).mean(axis=1)

fig, axes = plt.subplots(1, 2, figsize=(14, 5))
ax = axes[0]
ax.plot(load_mae_day, color='steelblue', lw=1, alpha=0.7,
        label=f'负荷MAE (均值={load_mae_day.mean():.0f} kW)')
ax.plot(pv_mae_day,   color='orange',   lw=1, alpha=0.7,
        label=f'光伏MAE (均值={pv_mae_day.mean():.0f} kW)')
ax.axhline(load_mae_day.mean(), color='steelblue', ls='--', lw=1.2)
ax.axhline(pv_mae_day.mean(),   color='orange',    ls='--', lw=1.2)
ax.set_xlabel('日期序号', fontsize=11)
ax.set_ylabel('MAE (kW)', fontsize=11)
ax.set_title('SARIMA逐日预测误差（MAE）', fontsize=11, fontweight='bold')
ax.legend(fontsize=9)
ax.grid(True, alpha=0.3)

ax2 = axes[1]
avg_buy = df_pur.iloc[:, 1:145].values.astype(float).mean(axis=0)
sc = ax2.scatter(price, avg_buy, c=avg_buy, cmap='RdYlBu_r', alpha=0.65, s=25)
ax2.set_xlabel('电价 (元/kWh)', fontsize=11)
ax2.set_ylabel('全年平均计划购电量 (kW)', fontsize=11)
ax2.set_title('电价与计划购电量相关性散点图', fontsize=11, fontweight='bold')
plt.colorbar(sc, ax=ax2, label='购电量 (kW)')
ax2.grid(True, alpha=0.3)
line = Line2D([0.513, 0.513], [0.05, 0.92], transform=fig.transFigure, color='gray', linewidth=1.5)
fig.add_artist(line)
plt.tight_layout()
plt.savefig(OUT / 'fig5_price_purchase_analysis.png', dpi=150, bbox_inches='tight')
plt.close()
print('fig5 done')

# 图6：两阶段偏差 — 逐日计划购电 vs 紧急购电
df_emg.columns = ['日期', '时间段', '购电量']

def safe_ts(s):
    try:
        return pd.Timestamp(str(s))
    except Exception:
        return pd.NaT

df_emg['日期_ts'] = df_emg['日期'].apply(safe_ts)
emg_clean = df_emg.dropna(subset=['日期_ts'])
emg_daily = (emg_clean.groupby(emg_clean['日期_ts'].dt.normalize())['购电量']
             .sum().reset_index())
emg_daily.columns = ['date', 'emg_qty']
emg_daily['date'] = pd.to_datetime(emg_daily['date'])

df_m = df_pur[['date', '全天购电量', '全天购电费']].merge(emg_daily, on='date', how='left')
df_m['emg_qty'] = df_m['emg_qty'].fillna(0)
df_m['emg_pct'] = df_m['emg_qty'] / df_m['全天购电量'].replace(0, np.nan) * 100

fig, axes = plt.subplots(1, 2, figsize=(14, 5))
x = np.arange(len(df_m))

ax = axes[0]
ax.fill_between(x, df_m['全天购电量'] / 10000, alpha=0.3, color='steelblue',
                label='计划购电量 (万kWh)')
ax.fill_between(x, df_m['emg_qty'] / 10000, alpha=0.55, color='red',
                label='紧急购电量 (万kWh)')
ax.set_xlabel('日期序号', fontsize=11)
ax.set_ylabel('购电量 (万kWh)', fontsize=11)
ax.set_title('全年逐日计划购电与紧急购电量对比', fontsize=11, fontweight='bold')
ax.legend(fontsize=9)
ax.grid(True, alpha=0.3)
total_emg = df_m['emg_qty'].sum()
ax.text(0.98, 0.97,
        f'全年紧急购电总量\n{total_emg/10000:.2f}万kWh',
        transform=ax.transAxes, va='top', ha='right', fontsize=9,
        bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.9))

ax2 = axes[1]
ax2.plot(x, df_m['emg_pct'].fillna(0), color='red', lw=0.8, alpha=0.6)
mean_pct = df_m['emg_pct'].mean()
ax2.axhline(mean_pct, color='red', ls='--', lw=1.5,
            label=f'均值={mean_pct:.2f}%')
ax2.set_xlabel('日期序号', fontsize=11)
ax2.set_ylabel('紧急购电占比 (%)', fontsize=11)
ax2.set_title('逐日紧急购电占当日购电量占比', fontsize=11, fontweight='bold')
ax2.legend(fontsize=9)
ax2.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(OUT / 'fig6_soc_analysis.png', dpi=150, bbox_inches='tight')
plt.close()
print('fig6 done')

print('\n所有图片生成完成！')
print(f'输出目录: {OUT}')
