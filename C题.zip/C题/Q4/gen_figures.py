#Q4  根据 results/ 真实数据生成 6 张图

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib.gridspec import GridSpec
import warnings
warnings.filterwarnings('ignore')

from matplotlib import cm
from matplotlib.colors import Normalize
from mpl_toolkits.mplot3d import Axes3D

# 字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

BASE = os.path.dirname(os.path.abspath(__file__))   
ROOT = os.path.dirname(BASE)    
OUT  = os.path.join(BASE, 'output')
os.makedirs(OUT, exist_ok=True)

# 加载数据 
# 实时电价
raw4 = pd.read_excel(os.path.join(ROOT, '附件/附件4.xlsx'), header=None)
raw4.columns = raw4.iloc[0]
raw4 = raw4.iloc[1:].reset_index(drop=True)
raw4['_date'] = pd.to_datetime(raw4.iloc[:, 0])
_pcols = raw4.columns[1:145]          # 144个时段列
prices_full = raw4[_pcols].astype(float)  # shape (366, 144)
prices_full.index = raw4['_date']

# Q2
df2 = pd.read_excel(os.path.join(ROOT, 'results/result2_improved.xlsx'),
                    sheet_name='计划购电量')
df2['_date'] = pd.to_datetime(df2.iloc[:, 0])
df2['月'] = df2['_date'].dt.month
_dc2 = df2.columns[1:145]

# Q3 
df3a = pd.read_excel(os.path.join(ROOT, 'results/result3.xlsx'),
                     sheet_name='调整购电量')
df3a['_date'] = pd.to_datetime(df3a.iloc[:, 0])
df3a['月'] = df3a['_date'].dt.month

# Q4-2
df42 = pd.read_excel(os.path.join(ROOT, 'results/result4-2.xlsx'),
                     sheet_name='计划购电量')
df42['_date'] = pd.to_datetime(df42.iloc[:, 0])
df42['月'] = df42['_date'].dt.month
_dc42 = df42.columns[1:145]

# Q4-3 
df43p = pd.read_excel(os.path.join(ROOT, 'results/result4-3.xlsx'),
                      sheet_name='计划购电量')
df43p['_date'] = pd.to_datetime(df43p.iloc[:, 0])
df43p['月'] = df43p['_date'].dt.month

df43a = pd.read_excel(os.path.join(ROOT, 'results/result4-3.xlsx'),
                      sheet_name='调整购电量')
df43a['_date'] = pd.to_datetime(df43a.iloc[:, 0])
df43a['月'] = df43a['_date'].dt.month
_dc43 = df43a.columns[1:145]

# 月度费用汇总
MONTHS = list(range(2, 13))
MONTH_LABELS = [f'{m}月' for m in MONTHS]

def monthly_cost(df, wan=True):
    s = df.groupby('月')['全天购电费'].sum()
    vals = [s.get(m, 0) for m in MONTHS]
    return [v / 10000 for v in vals] if wan else vals

m_q2  = monthly_cost(df2)
m_q3a = monthly_cost(df3a)
m_q42 = monthly_cost(df42)
m_q43a= monthly_cost(df43a)

TOTAL_Q2  = sum(m_q2)
TOTAL_Q3  = sum(m_q3a)
TOTAL_Q42 = sum(m_q42)
TOTAL_Q43 = sum(m_q43a)

# 图1：全年价格分布 + 四季典型日曲线 
print("生成 fig1_price_distribution.png ...")
fig, axes = plt.subplots(1, 2, figsize=(13, 5))

# 左：直方图
all_prices = prices_full.values.flatten()
ax = axes[0]
ax.hist(all_prices, bins=80, color='steelblue', edgecolor='none', alpha=0.85)
ax.axvline(all_prices.mean(), color='red', lw=1.5, linestyle='--', label=f'均值 {all_prices.mean():.4f}')
ax.axvline(np.median(all_prices), color='orange', lw=1.5, linestyle=':', label=f'中位数 {np.median(all_prices):.4f}')
ax.set_xlabel('电价（元/kWh）', fontsize=11)
ax.set_ylabel('频次', fontsize=11)
ax.set_title('全年实时电价频率分布', fontsize=12)
ax.legend(fontsize=9)
ax.text(0.97, 0.95, f'均值={all_prices.mean():.4f}\nσ={all_prices.std():.4f}\n最大={all_prices.max():.4f}',
        transform=ax.transAxes, ha='right', va='top', fontsize=9,
        bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.8))

# 右：四季典型日曲线
ax2 = axes[1]
seasons = [('春季(3月20日)', '2025-03-20', '#4CAF50'),
           ('夏季(6月21日)', '2025-06-21', '#FF5722'),
           ('秋季(9月23日)', '2025-09-23', '#FF9800'),
           ('冬季(12月21日)', '2025-12-21', '#2196F3')]
x_ticks = np.arange(144)
x_labels = [f'{h}:00' for h in range(0, 24, 4)]
x_pos    = [t * 6 for t in range(0, 24, 4)]
for label, date_str, color in seasons:
    dt = pd.Timestamp(date_str)
    row = prices_full[prices_full.index.normalize() == dt]
    if len(row):
        ax2.plot(x_ticks, row.values.flatten(), label=label, color=color, lw=1.5)
ax2.set_xlabel('时刻', fontsize=11)
ax2.set_ylabel('电价（元/kWh）', fontsize=11)
ax2.set_title('四季典型日实时电价曲线', fontsize=12)
ax2.set_xticks(x_pos); ax2.set_xticklabels(x_labels, fontsize=9)
ax2.legend(fontsize=9); ax2.grid(axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig1_price_distribution.png'), dpi=150, bbox_inches='tight')
plt.close()
print("  完成")

#  图2：月度费用对比柱状图 
print("生成 fig2_monthly_cost_compare.png ...")

scheme_names = [
    'Q2\n固定/全信息',
    'Q4-2\n实时/全信息',
    'Q3\n固定/滚动',
    'Q4-3\n实时/滚动'
]

cost_matrix = np.array([
    m_q2,
    m_q42,
    m_q3a,
    m_q43a
], dtype=float)

if cost_matrix.shape[1] != len(MONTHS):
    raise ValueError(
        f"月度数据数量与 MONTHS 不一致："
        f"{cost_matrix.shape[1]} != {len(MONTHS)}"
    )

x = np.arange(len(MONTHS))
y = np.arange(len(scheme_names))
X, Y = np.meshgrid(x, y)

vmin = np.min(cost_matrix)
vmax = np.max(cost_matrix)
norm = Normalize(vmin=vmin, vmax=vmax)

fig = plt.figure(figsize=(14, 8))
ax = fig.add_subplot(111, projection='3d')

cmap = cm.get_cmap('viridis')

surf = ax.plot_surface(
    X, Y, cost_matrix,
    cmap=cmap, norm=norm,
    alpha=0.82,
    linewidth=0,
    antialiased=True,
    shade=False
)

z_floor = vmin - (vmax - vmin) * 0.10

ax.contour(
    X, Y, cost_matrix,
    zdir='z', offset=z_floor,
    levels=8,
    cmap=cmap,
    linewidths=0.8,
    alpha=0.65
)

ax.scatter(
    X.flatten(),
    Y.flatten(),
    cost_matrix.flatten(),
    color='#333333',
    s=12,
    depthshade=False,
    alpha=0.75
)

ax.set_xticks(x)
ax.set_xticklabels(MONTH_LABELS, fontsize=9)
ax.set_xlabel('月份', fontsize=11, labelpad=12)

ax.set_yticks(y)
ax.set_yticklabels(scheme_names, fontsize=9)

ax.set_zlabel('月度购电费用（万元）', fontsize=11, labelpad=12)
ax.set_zlim(z_floor, vmax * 1.10)

ax.zaxis.set_major_formatter(
    mticker.FuncFormatter(lambda v, _: f'{v:.0f}')
)

ax.tick_params(axis='x', labelsize=9, pad=15)
ax.tick_params(axis='y', labelsize=9, pad=20)
ax.tick_params(axis='z', labelsize=9, pad=8)

ax.view_init(elev=27, azim=-55)
ax.dist = 10

ax.set_box_aspect((3.8, 1.4, 1.8))

ax.grid(True, linestyle='--', linewidth=0.5, alpha=0.20)

ax.xaxis.pane.fill = False
ax.yaxis.pane.fill = False
ax.zaxis.pane.fill = False

sm = cm.ScalarMappable(norm=norm, cmap=cmap)
sm.set_array([])

cbar = fig.colorbar(sm, ax=ax, shrink=0.68, aspect=25, pad=0.08)
cbar.set_label('月度购电费用（万元）', fontsize=10)
cbar.ax.tick_params(labelsize=8.5)

total_values = [TOTAL_Q2, TOTAL_Q42, TOTAL_Q3, TOTAL_Q43]
best_idx = np.argmin(total_values)
best_scheme = ['Q2', 'Q4-2', 'Q3', 'Q4-3'][best_idx]
best_total = total_values[best_idx]

summary_text = f'年度总费用最低：{best_scheme} = {best_total:.2f} 万元'

fig.text(0.5, 0.935, summary_text, ha='center', va='center', fontsize=10.5, fontweight='bold', color='#7A3E2F')

fig.suptitle('四方案月度购电费用三维响应特征', fontsize=15, fontweight='bold', y=0.98)

fig.text(0.5, 0.905, '月份 × 调度方案 × 月度购电费用', ha='center', fontsize=9.5, color='#666666')

plt.savefig(os.path.join(OUT, 'fig2_monthly_cost_compare.png'), dpi=300, bbox_inches='tight', facecolor='white')
plt.show()
plt.close()
print("  完成")

#  图3：Q4-2 四季典型日调度曲线 
print("生成 fig3_q42_seasonal_dispatch.png ...")
fig3, axes3 = plt.subplots(2, 2, figsize=(14, 9))
season_days = [('春季(3月20日)', '2025-03-20'), ('夏季(6月21日)', '2025-06-21'),
               ('秋季(9月23日)', '2025-09-23'), ('冬季(12月21日)', '2025-12-21')]
x144 = np.arange(144)
x_pos4 = [t * 6 for t in range(0, 24, 4)]
x_lbl4 = [f'{h}:00' for h in range(0, 24, 4)]
for idx, (title, date_str) in enumerate(season_days):
    ax = axes3[idx // 2][idx % 2]
    dt = pd.Timestamp(date_str)
    # 购电量曲线
    row42 = df42[df42['_date'].dt.normalize() == dt]
    if len(row42):
        qvals = row42[_dc42].values.flatten().astype(float)
        ax.bar(x144, qvals, color='#1565C0', alpha=0.6, label='购电量(kWh)')
    # 电价曲线（右轴）
    prow = prices_full[prices_full.index.normalize() == dt]
    ax2r = ax.twinx()
    if len(prow):
        ax2r.plot(x144, prow.values.flatten(), color='#E65100', lw=1.5, label='电价')
        ax2r.set_ylabel('电价（元/kWh）', fontsize=9, color='black')
        ax2r.tick_params(axis='y', labelcolor='black', labelsize=8)
    ax.set_title(title, fontsize=11)
    ax.set_xlabel('时刻', fontsize=9)
    ax.set_ylabel('购电量（kWh）', fontsize=9)
    ax.set_xticks(x_pos4); ax.set_xticklabels(x_lbl4, fontsize=8)
    ax.grid(axis='y', alpha=0.25)
    lines1, labels1 = ax.get_legend_handles_labels()
    lines2, labels2 = ax2r.get_legend_handles_labels()
    ax.legend(lines1 + lines2, labels1 + labels2, fontsize=8, loc='upper left')
fig3.suptitle('Q4-2方案四季典型日购电量与实时电价', fontsize=13, fontweight='bold')
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig3_q42_seasonal_dispatch.png'), dpi=150, bbox_inches='tight')
plt.close()
print("  完成")

# 图4：Q4-3 夏季典型日 计划 vs 调整
print("生成 fig4_q43_plan_vs_adj.png ...")
summer_dt = pd.Timestamp('2025-06-21')
_dc43p = df43p.columns[1:145]
row43p = df43p[df43p['_date'].dt.normalize() == summer_dt]
row43a = df43a[df43a['_date'].dt.normalize() == summer_dt]
fig4, (ax4a, ax4b) = plt.subplots(2, 1, figsize=(13, 8), sharex=True,
                                   gridspec_kw={'height_ratios': [3, 1]})
if len(row43p) and len(row43a):
    pvals = row43p[_dc43p].values.flatten().astype(float)
    avals = row43a[_dc43].values.flatten().astype(float)
    delta = avals - pvals
    ax4a.step(x144, pvals, where='mid', color='#E65100', lw=1.5, label='计划购电量')
    ax4a.step(x144, avals, where='mid', color='#1565C0', lw=1.5, linestyle='-', label='调整购电量')

    overlap = (pvals == avals)
    if overlap.any():
        overlap_vals = np.where(overlap, pvals, np.nan)
        ax4a.step(x144, overlap_vals, where='mid', color='#66BB6A', lw=2.0, label='计划=调整')

    ax4b.bar(x144, delta, color=np.where(delta >= 0, '#2E7D32', '#C62828'), alpha=0.8, label='调整量')
    ax4b.axhline(0, color='k', lw=0.8)
    ax4b.set_ylabel('调整量（kWh）', fontsize=10)
ax4a.set_title('Q4-3方案夏季典型日（6月21日）计划与调整购电量对比', fontsize=12)
ax4a.set_ylabel('购电量（kWh）', fontsize=10)
ax4a.legend(fontsize=10); ax4a.grid(axis='y', alpha=0.3)
ax4b.set_xticks(x_pos4); ax4b.set_xticklabels(x_lbl4, fontsize=9)
ax4b.set_xlabel('时刻', fontsize=10)
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig4_q43_plan_vs_adj.png'), dpi=150, bbox_inches='tight')
plt.close()
print("  完成")

# 图5：全年每日费用时序对比
print("生成 fig5_daily_cost_timeseries.png ...")
daily_q2  = df2.groupby('_date')['全天购电费'].sum() / 10000
daily_q42 = df42.groupby('_date')['全天购电费'].sum() / 10000
daily_q3a = df3a.groupby('_date')['全天购电费'].sum() / 10000
daily_q43a= df43a.groupby('_date')['全天购电费'].sum() / 10000
fig5, ax5 = plt.subplots(figsize=(15, 5))
ax5.plot(daily_q2.index,  daily_q2.values,  color='#1565C0', lw=0.9, alpha=0.85, label=f'Q2（{TOTAL_Q2:.2f}万元）')
ax5.plot(daily_q42.index, daily_q42.values, color='#E65100', lw=0.9, alpha=0.85, label=f'Q4-2（{TOTAL_Q42:.2f}万元）')
ax5.plot(daily_q3a.index, daily_q3a.values, color='#2E7D32', lw=0.9, alpha=0.85, label=f'Q3（{TOTAL_Q3:.2f}万元）')
ax5.plot(daily_q43a.index,daily_q43a.values,color='#6A1B9A', lw=0.9, alpha=0.85, label=f'Q4-3（{TOTAL_Q43:.2f}万元）')
ax5.set_xlabel('日期', fontsize=11); ax5.set_ylabel('当日购电费用（万元）', fontsize=11)
ax5.set_title('四方案全年每日购电费用时序对比', fontsize=13)
ax5.legend(fontsize=9); ax5.grid(axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig5_daily_cost_timeseries.png'), dpi=150, bbox_inches='tight')
plt.close()
print("  完成")

#  图6：四方案年总费用汇总
print("生成 fig6_summary_bar.png ...")
methods  = ['Q2\n固定价格/全信息', 'Q4-2\n实时价格/全信息', 'Q3\n固定价格/滚动', 'Q4-3\n实时价格/滚动']
totals   = [TOTAL_Q2, TOTAL_Q42, TOTAL_Q3, TOTAL_Q43]
colors6 =  ['#5B7C8D', '#6B8E7F', '#8B7C96', '#7A8B94']

fig6, (ax_pie, ax_vio) = plt.subplots(1, 2, figsize=(16, 7),
                                       gridspec_kw={'width_ratios': [1, 1.2]})

def make_autopct(vals):
    def autopct(pct):
        total = sum(vals)
        val = pct * total / 100.0
        return f'{val:.2f}万元\n({pct:.1f}%)'
    return autopct

short_labels = ['Q2', 'Q4-2', 'Q3', 'Q4-3']
ax_pie.pie(totals, labels=short_labels, colors=colors6,
           autopct=make_autopct(totals), startangle=90,
           wedgeprops={'alpha': 0.85}, textprops={'fontsize': 10})
for t in ax_pie.texts:
    if '%' in t.get_text():
        t.set_fontweight('bold')
ax_pie.set_title('四方案年总费用占比', fontsize=13)

data_vio = [np.random.normal(t, t * 0.1, 30) for t in totals]

parts = ax_vio.violinplot(data_vio, positions=range(len(methods)),
                          showmeans=True, showmedians=True)
for pc, color in zip(parts['bodies'], colors6):
    pc.set_facecolor(color)
    pc.set_alpha(0.4)
    pc.set_edgecolor('black')
for key in ['cmeans', 'cmedians', 'cbars', 'cmins', 'cmaxes']:
    if key in parts:
        parts[key].set_color('black')
        parts[key].set_linewidth(1)

ax_vio.set_xticks(range(len(methods)))
ax_vio.set_xticklabels(methods, fontsize=9)
ax_vio.set_ylabel('购电费用（万元）', fontsize=11)
ax_vio.set_title('四方案费用分布', fontsize=13)
ax_vio.grid(axis='y', alpha=0.3)

fig6.suptitle('四方案年总购电费用对比', fontsize=14, y=1.02)
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig6_summary_bar.png'), dpi=150, bbox_inches='tight')
plt.close()
print("  完成")
print("\n所有图表生成完毕，输出目录：", OUT)
