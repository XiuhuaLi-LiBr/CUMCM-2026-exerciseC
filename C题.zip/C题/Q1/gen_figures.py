#Q1  典型日优化结果，生成 6 张图

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
OUT  = os.path.join(BASE, 'output')
os.makedirs(OUT, exist_ok=True)

# 加载数据 
# 附件1: 典型日负载、光伏、电价
raw1 = pd.read_excel(os.path.join(ROOT, '附件/附件1.xlsx'), header=None)
raw1.columns = raw1.iloc[0]; raw1 = raw1.iloc[1:].reset_index(drop=True)
# 列: 时段, 电价, 负载, 光伏预测 (前144行)
price_col = raw1.columns[1]
load_col  = raw1.columns[2]
pv_col    = raw1.columns[3]
price  = raw1[price_col].astype(float).values[:144]
load   = raw1[load_col].astype(float).values[:144]
pv     = raw1[pv_col].astype(float).values[:144]

# result1_improved.xlsx: 计划购电量, 充放电量
df_plan = pd.read_excel(os.path.join(ROOT, 'results/result1_improved.xlsx'),
                        sheet_name='计划购电量', header=0)
df_chg  = pd.read_excel(os.path.join(ROOT, 'results/result1_improved.xlsx'),
                        sheet_name='充放电量', header=0)

# 144个时段购电量
e_buy = df_plan.iloc[:144, 1].astype(float).values   # kWh per period

# 时间轴
x = np.arange(144)
x_pos = [t * 6 for t in range(0, 24, 4)]
x_lbl = [f'{h}:00' for h in range(0, 24, 4)]

DELTA_T = 1/6   # h per period
P_buy = e_buy / DELTA_T   # kW

# 典型日无储能基准费用（直接购电满足需求）
cost_no_storage = np.sum(np.maximum(load - pv, 0) * price * DELTA_T)
cost_with_storage = np.sum(P_buy * price * DELTA_T)
saving = cost_no_storage - cost_with_storage
saving_pct = saving / cost_no_storage * 100

print(f"有储能购电费: {cost_with_storage:.2f} 元")
print(f"无储能购电费: {cost_no_storage:.2f} 元")
print(f"节省: {saving:.2f} 元 ({saving_pct:.1f}%)")

#图7：典型日储能分阶段充放电特征

time_labels = ['0:00–4:00','4:00–8:00','8:00–12:00','12:00–16:00','16:00–20:00','20:00–24:00']
charge = np.array([4500.00, 833.33, 4787.96, 5286.04, 0.00, 5333.33])
discharge = np.array([0.00, 6365.84, 1703.00, 91.10, 5780.13, 2859.87])
x = np.arange(len(time_labels))
fig, ax = plt.subplots(figsize=(12, 5.5))
bars_c = ax.bar(x, charge, width=0.58, color='#5B7C99', alpha=0.72, edgecolor='#40566B', linewidth=0.7, label='充电量')
bars_d = ax.bar(x, -discharge, width=0.58, color='#C39A4B', alpha=0.72, edgecolor='#8A6D2F', linewidth=0.7, label='放电量')
# 0轴
ax.axhline(0, color='#4A4A4A', linewidth=1.0)
# 数据标签
for bar, val in zip(bars_c, charge):
    if val > 0:
        ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+180, f'{val:.0f}', ha='center', va='bottom', fontsize=8.5, color='#40566B')
for bar, val in zip(bars_d, discharge):
    if val > 0:
        ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()-180, f'{val:.0f}', ha='center', va='top', fontsize=8.5, color='#765B25')
# 坐标轴
ax.set_xticks(x)
ax.set_xticklabels(time_labels, fontsize=9.5)
ax.set_xlabel('时间段', fontsize=11)
ax.set_ylabel('储能充放电量（kWh）', fontsize=11)
ax.set_title('典型日储能分阶段充放电特征', fontsize=12.5, fontweight='bold')
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, pos: f'{abs(v):.0f}'))
ax.grid(axis='y', alpha=0.20, linestyle='--')
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.legend(fontsize=9.5, loc='upper left', frameon=True, framealpha=0.92)
# 标注日初/日末储电量
ax.text(0.98, 0.94, '0:00 储电量：6000 kWh\n24:00 储电量：6000 kWh',
        transform=ax.transAxes, ha='right', va='top', fontsize=9.5, color='#4A4A4A',
        bbox=dict(boxstyle='round,pad=0.35', facecolor='white', edgecolor='#B8B8B8', alpha=0.92))
# 充放电方向说明
ax.text(0.02, 0.96, '↑ 充电\n↓ 放电',
        transform=ax.transAxes, ha='left', va='top', fontsize=8.5, color='#555555')
plt.tight_layout()
plt.savefig(OUT + r'\fig7_storage_operation.png', bbox_inches='tight', dpi=300)
plt.close()
print('fig7 done')

#  图1：电价曲线与购电量 
print("生成 fig1_price_buy.png ...")
fig, ax1 = plt.subplots(figsize=(12, 5))
ax2 = ax1.twinx()
ax1.bar(x, P_buy, color='#1565C0', alpha=0.55, label='购电功率 (kW)', width=0.8)
ax2.plot(x, price, color='#E65100', lw=2, label='电价 (元/kWh)')
ax1.set_xlabel('时刻', fontsize=11); ax1.set_ylabel('购电功率（kW）', fontsize=11)
ax2.set_ylabel('电价（元/kWh）', fontsize=11, color='black')
ax2.tick_params(axis='y', labelcolor='black')
ax1.set_xticks(x_pos); ax1.set_xticklabels(x_lbl, fontsize=9)
ax1.set_title('典型日购电功率与分时电价', fontsize=13)
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=10, loc='upper left')
ax1.grid(axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig1_price_buy.png'), dpi=150, bbox_inches='tight')
plt.close()
print("  完成")

#  图2：供需平衡分析 
print("生成 fig2_supply_demand.png ...")

fig, ax = plt.subplots(figsize=(12, 5.5))

# ==================== 学术配色 ====================
c_pv = '#C39A4B'       # 哑金：光伏
c_buy = '#5B7C99'      # 灰蓝：购电
c_load = '#8C5A5A'     # 灰红棕：负荷
c_grid = '#B8C0C8'      # 淡灰：辅助网格

# ==================== 原始数据折线 ====================
ax.plot(x, pv, color=c_pv, lw=1.8, label='光伏出力（kW）', zorder=3)
ax.plot(x, P_buy, color=c_buy, lw=1.8, label='购电功率（kW）', zorder=3)
ax.plot(x, load, color=c_load, lw=2.6, label='负载需求（kW）', zorder=4)

# ==================== 滚动波动带 ====================
window = max(3, min(12, len(x)//20))
pv_mean = pd.Series(pv).rolling(window, center=True, min_periods=1).mean()
pv_std = pd.Series(pv).rolling(window, center=True, min_periods=1).std().fillna(0)
buy_mean = pd.Series(P_buy).rolling(window, center=True, min_periods=1).mean()
buy_std = pd.Series(P_buy).rolling(window, center=True, min_periods=1).std().fillna(0)

ax.fill_between(x, np.maximum(0, pv_mean-pv_std), pv_mean+pv_std, color=c_pv, alpha=0.12, linewidth=0)
ax.fill_between(x, np.maximum(0, buy_mean-buy_std), buy_mean+buy_std, color=c_buy, alpha=0.10, linewidth=0)

# ==================== 识别关键运行区间 ====================
surplus = pv > load
grid_depend = P_buy > 0

# 找连续区间
def get_segments(mask):
    segments = []
    start = None
    for i, flag in enumerate(mask):
        if flag and start is None:
            start = i
        elif not flag and start is not None:
            segments.append((start, i-1))
            start = None
    if start is not None:
        segments.append((start, len(mask)-1))
    return segments

surplus_seg = get_segments(surplus)
grid_seg = get_segments(grid_depend)

# 只标注较长、具有代表性的区间，避免视觉拥挤
if surplus_seg:
    seg = max(surplus_seg, key=lambda z: z[1]-z[0])
    if seg[1]-seg[0] >= max(2, len(x)//30):
        mid = (seg[0]+seg[1])//2
        ax.annotate('光伏出力高于负荷',
                    xy=(x[mid], pv[mid]),
                    xytext=(x[mid], max(pv)*0.88),
                    ha='center', fontsize=9, color='#765B25',
                    arrowprops=dict(arrowstyle='->', color='#765B25', lw=0.8),
                    bbox=dict(boxstyle='round,pad=0.3', facecolor='white', edgecolor='#D6C28A', alpha=0.9))

if grid_seg:
    seg = max(grid_seg, key=lambda z: z[1]-z[0])
    if seg[1]-seg[0] >= max(2, len(x)//30):
        mid = (seg[0]+seg[1])//2
        ax.annotate('外部电网供电依赖',
                    xy=(x[mid], P_buy[mid]),
                    xytext=(x[mid], max(load)*0.55),
                    ha='center', fontsize=9, color='#4D657D',
                    arrowprops=dict(arrowstyle='->', color='#4D657D', lw=0.8),
                    bbox=dict(boxstyle='round,pad=0.3', facecolor='white', edgecolor='#B8C4CF', alpha=0.9))

# ==================== 坐标轴与格式 ====================
ax.set_xlabel('时刻', fontsize=11)
ax.set_ylabel('功率（kW）', fontsize=11)
ax.set_xticks(x_pos)
ax.set_xticklabels(x_lbl, fontsize=9)

ax.set_title('典型日光伏、购电与负荷需求的供需关系', fontsize=13, fontweight='bold', pad=10)

ax.legend(fontsize=9.5, loc='upper left', frameon=True, framealpha=0.92)
ax.grid(axis='y', color=c_grid, alpha=0.25, linestyle='--', linewidth=0.7)

ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

# ==================== 数据关系说明 ====================
pv_total = np.sum(pv)
buy_total = np.sum(P_buy)
load_total = np.sum(load)

ax.text(0.99, 0.97,
        f'典型日总量：光伏 {pv_total/6:.1f} kWh｜购电 {buy_total/6:.1f} kWh｜负荷 {load_total/6:.1f} kWh',
        transform=ax.transAxes, ha='right', va='top', fontsize=8.5, color='#555555',
        bbox=dict(boxstyle='round,pad=0.3', facecolor='white', edgecolor='#D0D0D0', alpha=0.9))

plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig2_supply_demand.png'), dpi=300, bbox_inches='tight')
plt.close()

print("  完成")

#  图3：SOC曲线（用充放电数据反推）
print("生成 fig3_soc_curve.png ...")
# 从充放电表读充放电量（kWh/4h段）
# 重新用greedy仿真计算SOC曲线
ETA_CH = 0.9; ETA_DIS = 0.9
E_MAX = 10800; E_MIN = 1200; E_INIT = 6000
soc = np.zeros(145)
soc[0] = E_INIT
p_ch = np.zeros(144); p_dis = np.zeros(144)
for t in range(144):
    net = P_buy[t] + pv[t] - load[t]
    if net >= 0:
        e_room = (E_MAX - soc[t]) / ETA_CH * 6   # kW
        pc = min(net, 5000, max(e_room, 0))
        p_ch[t] = pc
        soc[t+1] = soc[t] + pc * ETA_CH * DELTA_T
    else:
        need = -net
        e_avail = (soc[t] - E_MIN) * ETA_DIS * 6  # kW
        pd_ = min(need, 5000, max(e_avail, 0))
        p_dis[t] = pd_
        soc[t+1] = soc[t] - pd_ / ETA_DIS * DELTA_T

fig, ax = plt.subplots(figsize=(12, 5))
ax.plot(np.arange(145), soc, color='#2E7D32', lw=2, label='储能电量 (kWh)')
ax.axhline(E_MAX, color='red', lw=1, linestyle='--', alpha=0.7, label=f'上限 {E_MAX} kWh')
ax.axhline(E_MIN, color='orange', lw=1, linestyle='--', alpha=0.7, label=f'下限 {E_MIN} kWh')
ax.axhline(E_INIT, color='gray', lw=1, linestyle=':', alpha=0.7, label=f'初始/终态 {E_INIT} kWh')
ax.set_xlabel('时刻', fontsize=11); ax.set_ylabel('储能电量（kWh）', fontsize=11)
xt = list(x_pos) + [144]
xl = list(x_lbl) + ['24:00']
ax.set_xticks(xt); ax.set_xticklabels(xl, fontsize=9)
ax.set_title('典型日储能电量（SOC）曲线', fontsize=13)
ax.legend(fontsize=10); ax.grid(axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig3_soc_curve.png'), dpi=150, bbox_inches='tight')
plt.close()
print("  完成")

#  图4：充放电功率曲线 
print("生成 fig4_charge_discharge.png ...")
fig, ax = plt.subplots(figsize=(12, 5))

offset = max(p_dis) * 0.15

ax.plot(x, p_ch, color='#43A047', lw=2, marker='o', ms=3, label='充电功率 (kW)')
ax.plot(x, -p_dis - offset, color='#E53935', lw=2, marker='s', ms=3, label='放电功率 (kW)')

ax.axhline(0, color='k', lw=0.8)
ax.axhline(-offset, color='grey', lw=0.5, ls='--')

xlim = ax.get_xlim()
ax.text(xlim[0], 0, ' 充电功率=0', va='center', ha='right', fontsize=9, color='#43A047')
ax.text(xlim[0], -offset, ' 放电功率=0', va='center', ha='right', fontsize=9, color='#E53935')

ax.set_xlabel('时刻', fontsize=11)
ax.set_ylabel('功率（kW）', fontsize=11)
ax.set_xticks(x_pos)
ax.set_xticklabels(x_lbl, fontsize=9)
ax.set_title('典型日储能充放电功率', fontsize=13)
ax.legend(fontsize=10)
ax.grid(axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig4_charge_discharge.png'), dpi=150, bbox_inches='tight')
plt.close()
print("  完成")

#  图5：电价-购电量散点图 
print("生成 fig5_price_buy_scatter.png ...")
fig, ax = plt.subplots(figsize=(8, 6))
sc = ax.scatter(price, P_buy, c=x, cmap='viridis', alpha=0.7, s=30)
plt.colorbar(sc, ax=ax, label='时段序号')
ax.set_xlabel('电价（元/kWh）', fontsize=11)
ax.set_ylabel('购电功率（kW）', fontsize=11)
ax.set_title('分时电价与购电功率的关系', fontsize=13)
ax.grid(alpha=0.3)
corr = np.corrcoef(price, P_buy)[0, 1]
ax.text(0.97, 0.97, f'相关系数 r = {corr:.3f}', transform=ax.transAxes,
        ha='right', va='top', fontsize=10,
        bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.85))
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig5_price_buy_scatter.png'), dpi=150, bbox_inches='tight')
plt.close()
print("  完成")

#  图6：有/无储能费用对比 
print("生成 fig6_cost_compare.png ...")

labels6 = ['无储能方案', '有储能方案']
costs6  = [cost_no_storage, cost_with_storage]
colors6 = ['#EF5350', '#1565C0']

total = sum(costs6)
fractions = [c / total for c in costs6]

angles = []
cum = 0
for f in fractions:
    angles.append((cum, cum + f * 2 * np.pi))
    cum += f * 2 * np.pi

fig = plt.figure(figsize=(10, 7))
ax = fig.add_subplot(111, projection='3d')

r = 1.0
h = 1.0
n_arc = 80
explode_dist = 0.15

for i, (a_start, a_end) in enumerate(angles):
    mid_angle = (a_start + a_end) / 2.0

    dx = explode_dist * np.cos(mid_angle)
    dy = explode_dist * np.sin(mid_angle)

    theta = np.linspace(a_start, a_end, n_arc)

    x_arc = r * np.cos(theta) + dx
    y_arc = r * np.sin(theta) + dy

    x_side = np.tile(x_arc, (2, 1))
    y_side = np.tile(y_arc, (2, 1))
    z_side = np.array([np.zeros_like(theta), np.full_like(theta, h)])

    alpha_val = 1.0 if i == 1 else 0.45

    ax.plot_surface(x_side, y_side, z_side,
                    color=colors6[i], alpha=alpha_val,
                    linewidth=0, antialiased=True, shade=True)

    r_top = np.linspace(0, r, 20)
    R, T = np.meshgrid(r_top, theta)
    x_top = R * np.cos(T) + dx
    y_top = R * np.sin(T) + dy
    z_top = np.full_like(x_top, h)

    ax.plot_surface(x_top, y_top, z_top,
                    color=colors6[i], alpha=alpha_val,
                    linewidth=0, antialiased=True, shade=True)

    r_bot = np.linspace(0, r, 20)
    R_b, T_b = np.meshgrid(r_bot, theta)
    x_bot = R_b * np.cos(T_b) + dx
    y_bot = R_b * np.sin(T_b) + dy
    z_bot = np.zeros_like(x_bot)

    ax.plot_surface(x_bot, y_bot, z_bot,
                    color=colors6[i], alpha=alpha_val,
                    linewidth=0, antialiased=True, shade=True)

for i, (a_start, a_end) in enumerate(angles):
    mid_angle = (a_start + a_end) / 2.0

    px = 0.5 + 0.38 * np.cos(mid_angle)
    py = 0.5 + 0.38 * np.sin(mid_angle)

    if i == 0:
        px += 0.16
        py -= 0.06

    pct = fractions[i] * 100
    ax.text2D(px, py,
              f'{labels6[i]}\n{costs6[i]:.0f}元\n({pct:.1f}%)',
              transform=ax.transAxes,
              ha='center', va='center',
              fontsize=10, fontweight='bold', color='#333333')

ax.set_xlim([-1.8, 1.8])
ax.set_ylim([-1.8, 1.8])
ax.set_zlim([0, 1.5])
ax.view_init(elev=30, azim=-60)
ax.set_axis_off()

note = f'节省 {saving:.2f} 元（{saving_pct:.1f}%）'

fig.suptitle('典型日有/无储能方案购电费用对比', fontsize=14, fontweight='bold', y=0.97)
fig.text(0.5, 0.03, note, ha='center', fontsize=11, color='#2E7D32', fontweight='bold')

plt.tight_layout()
plt.savefig(os.path.join(OUT, 'fig6_cost_compare.png'), dpi=300, bbox_inches='tight', facecolor='white')
plt.close()
print("  完成")

print(f"\n所有图表生成完毕，输出目录：{OUT}")
