"""
结果保存模块（重写版）
严格按照附件5的模板格式输出
"""

import numpy as np
import pandas as pd
from openpyxl import load_workbook
from pathlib import Path


def save_problem1_results_v2(results, output_path, template_path):
    """
    保存问题1的结果到Excel文件（按模板格式）

    Args:
        results: 优化结果字典
        output_path: 输出文件路径
        template_path: 模板文件路径
    """
    import shutil

    # 先复制模板文件到输出路径
    shutil.copy(template_path, output_path)

    # 加载复制后的文件
    template_wb = load_workbook(output_path)

    # 工作表1: 计划购电量
    ws_purchase = template_wb['计划购电量']
    E_buy = results['E_buy']  # 购电量 (kWh)

    # 填充144行购电量数据（从第2行开始，第1行是标题）
    for i in range(144):
        ws_purchase.cell(row=i+2, column=2, value=E_buy[i])

    # 工作表2: 充放电量
    ws_charge = template_wb['充放电量']
    P_charge = results['P_charge']
    P_discharge = results['P_discharge']
    E_storage = results['E_storage']

    # 计算各时间段的充放电量
    time_ranges = [
        (0, 24),    # 0:00-4:00
        (24, 48),   # 4:00-8:00
        (48, 72),   # 8:00-12:00
        (72, 96),   # 12:00-16:00
        (96, 120),  # 16:00-20:00
        (120, 144)  # 20:00-24:00
    ]

    for idx, (start, end) in enumerate(time_ranges):
        charge_energy = np.sum(P_charge[start:end] * (1/6))  # kWh
        discharge_energy = np.sum(P_discharge[start:end] * (1/6))  # kWh

        # 填充充电量和放电量（第2列和第3列）
        ws_charge.cell(row=idx+2, column=2, value=charge_energy)
        ws_charge.cell(row=idx+2, column=3, value=discharge_energy)

    # 填充0:00和24:00的储电量（第5列）
    ws_charge.cell(row=2, column=5, value=E_storage[0])    # 0:00储电量
    ws_charge.cell(row=3, column=5, value=E_storage[144])  # 24:00储电量

    # 保存文件
    template_wb.save(output_path)

    # 计算并打印总购电费
    total_cost = results['total_cost']
    total_purchase = results['total_purchase']

    print(f"\n  全天购电量: {total_purchase:.2f} kWh")
    print(f"  全天购电费: {total_cost:.2f} 元")


def _fmt_date(d):
    """将日期对象格式化为 2025/2/3 格式"""
    return f'{d.year}/{d.month}/{d.day}'


def save_problem2_results_v2(results_all_days, output_path, template_path):
    """
    保存问题2的结果到Excel文件（按模板格式）

    Args:
        results_all_days: 所有天的结果列表
        output_path: 输出文件路径
        template_path: 模板文件路径
    """
    import shutil

    # 先复制模板文件到输出路径
    shutil.copy(template_path, output_path)

    # 加载复制后的文件
    template_wb = load_workbook(output_path)

    # 工作表1: 计划购电量
    ws_purchase = template_wb['计划购电量']

    # 填充每天的购电量数据
    for day_idx, result in enumerate(results_all_days):
        row = day_idx + 2  # 从第2行开始
        E_buy = result['E_buy']  # 144个时段的购电量

        # 日期（第1列）
        date = result['date']
        ws_purchase.cell(row=row, column=1, value=_fmt_date(date))

        # 144个时段的购电量（第2-145列）
        for t in range(144):
            ws_purchase.cell(row=row, column=t+2, value=E_buy[t])

        # 全天购电量（第146列）
        total_purchase = result['total_purchase']
        ws_purchase.cell(row=row, column=146, value=total_purchase)

        # 全天购电费（第147列）
        total_cost = result['total_cost']
        ws_purchase.cell(row=row, column=147, value=total_cost)

    # 工作表2: 充放电量
    ws_charge = template_wb['充放电量']

    # 每天占7行（6个时间段 + 1行空行）
    time_ranges = [
        (0, 24),    # 0:00-4:00
        (24, 48),   # 4:00-8:00
        (48, 72),   # 8:00-12:00
        (72, 96),   # 12:00-16:00
        (96, 120),  # 16:00-20:00
        (120, 144)  # 20:00-24:00
    ]

    current_row = 2
    for day_idx, result in enumerate(results_all_days):
        date = result['date']
        P_charge = result['P_charge']
        P_discharge = result['P_discharge']
        E_storage = result['E_storage']

        for period_idx, (start, end) in enumerate(time_ranges):
            charge_energy = np.sum(P_charge[start:end] * (1/6))
            discharge_energy = np.sum(P_discharge[start:end] * (1/6))

            # 日期（第1列，只在第一行填写）
            if period_idx == 0:
                ws_charge.cell(row=current_row, column=1, value=_fmt_date(date))
                # 0:00储电量（第5-6列）
                ws_charge.cell(row=current_row, column=6, value=E_storage[0])

            # 充电量和放电量（第3-4列）
            ws_charge.cell(row=current_row, column=3, value=charge_energy)
            ws_charge.cell(row=current_row, column=4, value=discharge_energy)

            # 24:00储电量（第二行）
            if period_idx == 1:
                ws_charge.cell(row=current_row, column=6, value=E_storage[144])

            current_row += 1

    # 工作表3: 紧急购电量
    ws_emergency = template_wb['紧急购电量']

    current_row = 2
    for day_idx, result in enumerate(results_all_days):
        date = result['date']
        P_emergency = result['P_emergency']

        # 找出紧急购电的时间段
        emergency_found = False
        i = 0
        while i < 144:
            if P_emergency[i] > 1e-6:
                # 找到紧急购电的起始
                start_t = i
                end_t = i

                # 找到连续紧急购电的结束
                while end_t < 143 and P_emergency[end_t + 1] > 1e-6:
                    end_t += 1

                # 计算时间段标签
                start_h = start_t // 6
                start_m = (start_t % 6) * 10
                end_h = (end_t + 1) // 6
                end_m = ((end_t + 1) % 6) * 10

                if end_m == 0 and end_h > 0:
                    end_h -= 1
                    end_m = 60

                time_label = f"{start_h}:{start_m:02d}-{end_h}:{end_m:02d}"

                # 计算购电量
                emergency_energy = np.sum(P_emergency[start_t:end_t+1] * (1/6))

                # 填充数据
                if not emergency_found:
                    ws_emergency.cell(row=current_row, column=1, value=_fmt_date(date))
                    emergency_found = True

                ws_emergency.cell(row=current_row, column=2, value=time_label)
                ws_emergency.cell(row=current_row, column=3, value=emergency_energy)

                current_row += 1
                i = end_t + 1
            else:
                i += 1

    # 清除模板中多余的示例行（⁝ / 2025/12/31 等）
    charge_last_row = 1 + len(results_all_days) * 6  # header + 334*6
    if ws_charge.max_row > charge_last_row:
        ws_charge.delete_rows(charge_last_row + 1, ws_charge.max_row - charge_last_row)

    purchase_last_row = 1 + len(results_all_days)
    if ws_purchase.max_row > purchase_last_row:
        ws_purchase.delete_rows(purchase_last_row + 1, ws_purchase.max_row - purchase_last_row)

    emerg_last_row = current_row - 1
    if ws_emergency.max_row > emerg_last_row:
        ws_emergency.delete_rows(emerg_last_row + 1, ws_emergency.max_row - emerg_last_row)

    # 保存文件
    template_wb.save(output_path)

    # 计算并打印总费用
    total_cost_all = sum([r['total_cost'] for r in results_all_days])
    total_purchase_all = sum([r['total_purchase'] for r in results_all_days])

    print(f"\n  总购电量: {total_purchase_all:.2f} kWh")
    print(f"  总购电费: {total_cost_all:.2f} 元")


def create_time_label(t_index):
    """
    创建时间段标签

    Args:
        t_index: 时间段索引 (0-143)

    Returns:
        str: 时间段标签，如 "0:10-0:20"
    """
    start_h = t_index // 6
    start_m = (t_index % 6) * 10

    end_t = t_index + 1
    if end_t == 144:
        return f"{start_h}:{start_m:02d}-0:00+1"
    else:
        end_h = end_t // 6
        end_m = (end_t % 6) * 10
        return f"{start_h}:{start_m:02d}-{end_h}:{end_m:02d}"


if __name__ == "__main__":
    print("结果保存模块（重写版）")

    # 测试时间标签生成
    print("\n时间标签测试:")
    for t in [0, 60, 71, 143]:
        print(f"  t={t}: {create_time_label(t)}")
