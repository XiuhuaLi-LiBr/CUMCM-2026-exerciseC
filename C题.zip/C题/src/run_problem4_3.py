"""
问题4-3：使用波动电价（附件4）重做问题3（带滚动调整策略）
修复：消除数据泄漏，优化阶段全程使用预报，真实数据仅用于greedy仿真。
"""

import sys
import os
import numpy as np
import pandas as pd
from pathlib import Path
import time

sys.path.append(str(Path(__file__).parent))

from data_loader import DataLoader
from optimizer_improved_p2 import ImprovedProblem2Optimizer
from optimizer_problem3 import Problem3Optimizer
from result_saver_p3 import save_problem3_results


def partial_hourly_to_10min(hourly_partial, n_hours):
    """将 n_hours 个整点预报插值到 n_hours*6 个10分钟时段。"""
    n_periods = n_hours * 6
    pts_hour = np.arange(n_hours + 1, dtype=float)
    vals_ext = np.append(hourly_partial[:n_hours], hourly_partial[n_hours - 1])
    pts_10min = np.arange(n_periods) / 6.0
    return np.maximum(np.interp(pts_10min, pts_hour, vals_ext), 0.0)


def greedy_simulate(pv_actual, load_actual, P_buy, E_start, t_start, t_end, opt):
    """greedy执行仿真：P_buy锁定，用真实数据跟踪SOC，缺口记为紧急购电。"""
    n = t_end - t_start
    P_ch = np.zeros(n); P_dis = np.zeros(n); P_emg = np.zeros(n)
    E = np.zeros(n + 1); E[0] = E_start
    for j in range(n):
        t = t_start + j
        net = P_buy[t] + pv_actual[t] - load_actual[t]
        if net >= 0.0:
            e_room = (opt.E_UPPER - E[j]) / opt.ETA_CH / opt.DELTA_T
            p_ch = min(net, opt.P_MAX, max(e_room, 0.0))
            P_ch[j] = p_ch
            E[j+1] = E[j] + p_ch * opt.ETA_CH * opt.DELTA_T
        else:
            need = -net
            e_avail = (E[j] - opt.E_MIN) * opt.ETA_DIS / opt.DELTA_T
            p_dis = min(need, opt.P_MAX, max(e_avail, 0.0))
            P_dis[j] = p_dis
            E[j+1] = E[j] - p_dis / opt.ETA_DIS * opt.DELTA_T
            gap = need - p_dis
            if gap > 1e-6:
                P_emg[j] = gap
    return {'P_charge': P_ch, 'P_discharge': P_dis, 'P_emergency': P_emg, 'E_storage': E}


def solve_problem4_3(data_dir, output_dir, template_dir, test_mode=False):
    print("=" * 60)
    print("问题4-3：波动电价 + 滚动调整优化（334天）")
    print("=" * 60)

    start_time = time.time()

    # 1. 加载数据
    print("\n[1/7] 加载数据...")
    loader = DataLoader(data_dir)

    # 加载附件4波动电价 (365, 144)
    data4 = loader.load_attachment4()
    price_all = data4['prices']   # shape (365, 144)
    print(f"  波动电价数据: {price_all.shape}  均值={price_all.mean():.4f} 元/kWh")

    # 加载附件2
    data2 = loader.load_attachment2()
    load_all = data2['load']
    pv_all = data2['pv_actual']
    dates_all = data2['dates']
    print(f"  负载数据: {load_all.shape}")

    # 加载附件3光伏预报
    data3 = loader.load_attachment3()
    forecasts = data3['forecasts']
    print(f"  预报数据: {len(forecasts)} 天")

    # 加载预计算 SARIMA 负载预报（与问题2/3共用）
    forecasts_npz_path = Path(output_dir) / 'forecasts_p2.npz'
    if not forecasts_npz_path.exists():
        raise FileNotFoundError(
            f"缺少预计算文件 {forecasts_npz_path}，请先运行 precompute_forecasts.py"
        )
    fc_npz = np.load(forecasts_npz_path, allow_pickle=True)
    fc_dates = fc_npz['dates']
    fc_load  = fc_npz['load_forecast']   # (334, 144)
    fc_date_map = {pd.Timestamp(str(d)).normalize(): idx for idx, d in enumerate(fc_dates)}
    print(f"  负载预报数据: {fc_load.shape}")

    # 2. 确定优化范围
    print("\n[2/7] 确定优化范围...")
    start_date = pd.Timestamp('2025-02-01')
    start_idx = int(np.where(dates_all == start_date)[0][0])
    dates = dates_all.iloc[start_idx:].reset_index(drop=True)
    load_data = load_all[start_idx:]
    pv_data = pv_all[start_idx:]

    n_days = len(dates) if not test_mode else 5
    print(f"  {'测试模式' if test_mode else '完整模式'}: {n_days} 天")

    # 3. 创建优化器
    print("\n[3/7] 创建优化器...")
    optimizer = Problem3Optimizer()
    warmup_optimizer = ImprovedProblem2Optimizer()

    # 4. 优化1月份（结果不写入输出，仅推算2月1日初始储能）
    print("\n[4/7] 优化1月份（结果不计入输出）...")
    E_init = 6000.0

    for day_idx in range(start_idx):
        if (day_idx + 1) % 10 == 0:
            print(f"    1月进度: {day_idx+1}/{start_idx}")

        price_day = price_all[day_idx]
        date = dates_all.iloc[day_idx]
        load_jan = load_all[day_idx]
        pv_jan = pv_all[day_idx]

        result = warmup_optimizer.solve(price_day, load_jan, pv_jan, E_init)

        if result:
            E_init = result['E_storage'][-1]
        else:
            print(f"  警告: 1月第{day_idx+1}天({date.strftime('%Y-%m-%d')})优化失败")

    print(f"  2月1日初始储能: {E_init:.2f} kWh")

    # 5. 逐天滚动优化
    print("\n[5/7] 开始滚动优化...")
    results_all_days = []

    for i in range(n_days):
        day_idx = start_idx + i
        date = dates[i]

        if (i + 1) % 30 == 0 or i == 0:
            elapsed = time.time() - start_time
            avg = elapsed / (i + 1 + start_idx)
            remaining = avg * (n_days - i - 1)
            print(f"  进度: {i+1}/{n_days} ({(i+1)/n_days*100:.1f}%) - {date.strftime('%Y-%m-%d')} - 预计剩余: {remaining/60:.1f}分钟")

        price_day   = price_all[day_idx]
        load_actual = load_data[i]   # 真实负载（仅用于greedy仿真）
        pv_actual   = pv_data[i]     # 真实光伏（仅用于greedy仿真）

        # 当天 ARIMA 负载预报（用于优化决策）
        fc_idx  = fc_date_map.get(pd.Timestamp(date).normalize())
        load_fc = load_actual if fc_idx is None else fc_load[fc_idx]

        # 0:00制定全天计划（使用预报）
        forecast_0h = forecasts.get(date, {}).get('0:00')
        if forecast_0h is None:
            print(f"  警告: {date.strftime('%Y-%m-%d')} 缺少0:00预报，跳过")
            continue

        planned_result = optimizer.solve_planned(price_day, load_fc, forecast_0h, E_init)
        if planned_result is None:
            print(f"  警告: {date.strftime('%Y-%m-%d')} 计划优化失败")
            continue

        P_final = planned_result['P_plan'].copy()

        # 全天结果数组（由greedy仿真逐段填充）
        P_charge_final    = np.zeros(144)
        P_discharge_final = np.zeros(144)
        P_emergency_final = np.zeros(144)
        E_storage_final   = np.zeros(145)
        E_storage_final[0] = E_init

        total_breach_cost = 0.0
        total_excess_cost = 0.0

        # greedy仿真 0:00→6:00
        seg = greedy_simulate(pv_actual, load_actual, P_final, E_init, 0, 36, optimizer)
        P_charge_final[0:36]    = seg['P_charge']
        P_discharge_final[0:36] = seg['P_discharge']
        P_emergency_final[0:36] = seg['P_emergency']
        E_storage_final[0:37]   = seg['E_storage']

        # 6:00 / 12:00 / 18:00 滚动调整 + greedy仿真
        for period_start, time_str, remaining_hours, seg_end in [
            (36,  '6:00',  18, 72),
            (72,  '12:00', 12, 108),
            (108, '18:00', 6,  144),
        ]:
            current_E = E_storage_final[period_start]  # 真实SOC

            forecast_t = forecasts.get(date, {}).get(time_str)
            if forecast_t is not None:
                # 附件3预报插值为10分钟（无数据泄漏）
                pv_fc_rem = partial_hourly_to_10min(
                    forecast_t[:remaining_hours], remaining_hours
                )
                adjusted_result = optimizer.solve_adjusted(
                    price_day,
                    load_fc[period_start:],   # ARIMA负载预报
                    pv_fc_rem,                 # 光伏预报
                    P_final,
                    current_E,
                    period_start
                )
                if adjusted_result is not None:
                    P_final[period_start:] = adjusted_result['P_adjusted']
                    total_breach_cost += adjusted_result['breach_cost']
                    total_excess_cost  += adjusted_result['excess_cost']

            # greedy仿真本段
            seg = greedy_simulate(
                pv_actual, load_actual, P_final,
                current_E, period_start, seg_end, optimizer
            )
            P_charge_final[period_start:seg_end]      = seg['P_charge']
            P_discharge_final[period_start:seg_end]   = seg['P_discharge']
            P_emergency_final[period_start:seg_end]   = seg['P_emergency']
            E_storage_final[period_start:seg_end + 1] = seg['E_storage']

        # 费用计算
        cost_0_6  = float(np.sum(planned_result['P_plan'][:36] * price_day[:36] * (1/6)))
        cost_6_24 = float(np.sum(P_final[36:] * price_day[36:] * (1/6)))
        emergency_cost_sim = float(np.sum(
            P_emergency_final * price_day * optimizer.EMERGENCY_RATIO * optimizer.DELTA_T
        ))
        total_cost_final = cost_0_6 + cost_6_24 + total_excess_cost - total_breach_cost + emergency_cost_sim

        result_day = {
            'date': date,
            'P_plan': planned_result['P_plan'],
            'P_final': P_final,
            'P_charge': planned_result['P_charge'],
            'P_discharge': planned_result['P_discharge'],
            'P_charge_final': P_charge_final,
            'P_discharge_final': P_discharge_final,
            'E_storage': planned_result['E_storage'],
            'E_storage_final': E_storage_final,
            'P_emergency': P_emergency_final,
            'total_cost': float(np.sum(planned_result['P_plan'] * price_day * (1/6))),
            'total_cost_final': total_cost_final,
            'adjustment_costs': {
                'breach': total_breach_cost,
                'excess': total_excess_cost,
                'emergency': emergency_cost_sim,
            },
        }

        results_all_days.append(result_day)
        E_init = E_storage_final[-1]   # 真实仿真末尾SOC

    print(f"\n  完成优化: {len(results_all_days)}/{n_days} 天")
    print(f"  总计算时间: {(time.time()-start_time)/60:.1f} 分钟")

    # 6. 保存结果
    print("\n[6/7] 保存结果...")
    template_path = Path(template_dir) / "result3.xlsx"
    output_path = Path(output_dir) / "result4-3.xlsx"
    save_problem3_results(results_all_days, output_path, template_path)
    print(f"  结果已保存到: {output_path}")

    # 7. 汇总
    print("\n[7/7] 结果汇总")
    print("=" * 60)

    total_cost = sum(r['total_cost_final'] for r in results_all_days)
    total_purchase = sum(np.sum(r['P_final'] * (1/6)) for r in results_all_days)
    total_breach = sum(r['adjustment_costs']['breach'] for r in results_all_days)
    total_excess = sum(r['adjustment_costs']['excess'] for r in results_all_days)
    total_emergency = sum(r['adjustment_costs']['emergency'] for r in results_all_days)

    print(f"  总购电费用: {total_cost:.2f} 元")
    print(f"  总购电量: {total_purchase:.2f} kWh")
    print(f"  调整退款（违约）: -{total_breach:.2f} 元")
    print(f"  调整惩罚（超出）: +{total_excess:.2f} 元")
    print(f"  紧急购电费用: +{total_emergency:.2f} 元")
    print(f"  平均日购电费用: {total_cost/len(results_all_days):.2f} 元/天")

    p42_ref = None  # 将在结合运行时对比
    p3_cost = 12090605.18
    diff = total_cost - p3_cost
    print(f"\n  对比问题3（固定电价）: {p3_cost:.2f} 元")
    print(f"  问题4-3费用: {total_cost:.2f} 元  差值: {diff:+.2f} 元")

    specified_dates = ['2025-03-20', '2025-06-21', '2025-09-23', '2025-12-21']
    print("\n指定日期结果:")
    print("-" * 60)
    for ds in specified_dates:
        td = pd.Timestamp(ds)
        match = [r for r in results_all_days if r['date'] == td]
        if match:
            r = match[0]
            print(f"  {ds}: 购电量={np.sum(r['P_final']*(1/6)):.2f} kWh  费用={r['total_cost_final']:.2f} 元")

    return results_all_days


if __name__ == "__main__":
    current_dir = Path(__file__).parent.parent
    data_dir = current_dir / "附件"
    output_dir = current_dir / "results"
    template_dir = current_dir / "附件" / "附件5"
    output_dir.mkdir(exist_ok=True)

    test_mode = '--test' in sys.argv
    results = solve_problem4_3(data_dir, output_dir, template_dir, test_mode=test_mode)

    if results:
        print("\n[OK] 问题4-3求解完成！")
    else:
        print("\n[FAIL] 问题4-3求解失败！")
