"""
问题3求解脚本：带预报更新的滚动优化
"""

import sys
import os
import numpy as np
import pandas as pd
from pathlib import Path
import time

sys.path.append(str(Path(__file__).parent))

from data_loader import DataLoader
from optimizer_improved_p2 import ImprovedProblem2Optimizer
from optimizer_problem3 import Problem3Optimizer
from result_saver_p3 import save_problem3_results


def partial_hourly_to_10min(hourly_partial, n_hours):
    """
    将 n_hours 个整点预报插值到 n_hours*6 个10分钟时段。
    hourly_partial: 从某调整时刻起的光伏预报, 取前 n_hours 个值
    """
    n_periods = n_hours * 6
    pts_hour = np.arange(n_hours + 1, dtype=float)
    vals_ext = np.append(hourly_partial[:n_hours], hourly_partial[n_hours - 1])
    pts_10min = np.arange(n_periods) / 6.0
    return np.interp(pts_10min, pts_hour, vals_ext)


def greedy_simulate(pv_actual, load_actual, P_buy, E_start, t_start, t_end, opt):
    """
    在 [t_start, t_end) 时段内执行 greedy 仿真。
    P_buy 已锁定，使用真实 PV 和负载，跟踪真实 SOC。
    超过放电能力的缺口记为紧急购电。
    """
    n = t_end - t_start
    P_ch  = np.zeros(n)
    P_dis = np.zeros(n)
    P_emg = np.zeros(n)
    E     = np.zeros(n + 1)
    E[0]  = E_start

    for j in range(n):
        t   = t_start + j
        net = P_buy[t] + pv_actual[t] - load_actual[t]

        if net >= 0.0:
            # 盈余 → 充电（受功率和容量限制）
            e_room = (opt.E_UPPER - E[j]) / opt.ETA_CH / opt.DELTA_T
            p_ch   = min(net, opt.P_MAX, max(e_room, 0.0))
            P_ch[j] = p_ch
            E[j+1]  = E[j] + p_ch * opt.ETA_CH * opt.DELTA_T
        else:
            # 缺口 → 放电，不足则紧急购电
            need    = -net
            e_avail = (E[j] - opt.E_MIN) * opt.ETA_DIS / opt.DELTA_T
            p_dis   = min(need, opt.P_MAX, max(e_avail, 0.0))
            P_dis[j] = p_dis
            E[j+1]   = E[j] - p_dis / opt.ETA_DIS * opt.DELTA_T
            gap = need - p_dis
            if gap > 1e-6:
                P_emg[j] = gap

    return {'P_charge': P_ch, 'P_discharge': P_dis, 'P_emergency': P_emg, 'E_storage': E}


def solve_problem3(data_dir, output_dir, template_dir, test_mode=False):
    """
    求解问题3：带预报更新的购电策略优化

    Args:
        data_dir: 数据目录
        output_dir: 输出目录
        template_dir: 模板目录
        test_mode: 是否为测试模式（只运行前几天）

    Returns:
        list: 所有天的优化结果
    """
    print("=" * 60)
    print("问题3：带预报更新的滚动优化（334天）")
    print("=" * 60)

    start_time = time.time()

    # 1. 加载数据
    print("\n[1/7] 加载数据...")
    loader = DataLoader(data_dir)

    # 加载电价
    data1 = loader.load_attachment1()
    price = data1['price']
    print(f"  电价数据: {len(price)} 个时段")

    # 加载附件2：实际负载和光伏
    data2 = loader.load_attachment2()
    load_all = data2['load']  # (365, 144)
    pv_all = data2['pv_actual']  # (365, 144)
    dates_all = data2['dates']

    print(f"  负载数据: {load_all.shape}")
    print(f"  光伏数据: {pv_all.shape}")

    # 加载附件3：光伏预报
    data3 = loader.load_attachment3()
    forecasts = data3['forecasts']
    print(f"  预报数据: {len(forecasts)} 天")

    # 加载预计算 SARIMA 负载预报（与问题2共用）
    forecasts_npz_path = Path(output_dir) / 'forecasts_p2.npz'
    if not forecasts_npz_path.exists():
        raise FileNotFoundError(
            f"缺少预计算文件 {forecasts_npz_path}，请先运行 precompute_forecasts.py"
        )
    fc_npz = np.load(forecasts_npz_path, allow_pickle=True)
    fc_dates = fc_npz['dates']
    fc_pv = fc_npz['pv_forecast']      # (334, 144)
    fc_load = fc_npz['load_forecast']   # (334, 144)
    fc_date_map = {pd.Timestamp(str(d)).normalize(): idx for idx, d in enumerate(fc_dates)}
    print(f"  负载预报数据: {fc_load.shape}")

    # 2. 确定优化范围（2月1日到12月31日）
    print("\n[2/7] 确定优化范围...")
    start_date = pd.Timestamp('2025-02-01')
    start_idx = np.where(dates_all == start_date)[0][0]

    dates = dates_all.iloc[start_idx:].reset_index(drop=True)
    load_data = load_all[start_idx:]
    pv_data = pv_all[start_idx:]

    n_days = len(dates) if not test_mode else 5
    print(f"  优化范围: 2025-02-01 到 2025-12-31")
    print(f"  {'测试模式' if test_mode else '完整模式'}: {n_days} 天")

    # 3. 创建优化器
    print("\n[3/7] 创建优化器...")
    optimizer = Problem3Optimizer()
    warmup_optimizer = ImprovedProblem2Optimizer()

    # 4. 优化1月份（结果不写入输出，仅推算2月1日初始储能）
    print("\n[4/7] 优化1月份（结果不计入输出）...")
    E_init = 6000

    print("  优化1月份（31天）...")
    for day_idx in range(start_idx):
        if (day_idx + 1) % 10 == 0:
            print(f"    1月进度: {day_idx+1}/{start_idx} 天")

        date = dates_all.iloc[day_idx]
        load_jan = load_all[day_idx]
        pv_jan = pv_all[day_idx]

        result = warmup_optimizer.solve(price, load_jan, pv_jan, E_init)

        if result:
            E_init = result['E_storage'][-1]
        else:
            print(f"  警告: 1月第{day_idx+1}天({date.strftime('%Y-%m-%d')})优化失败")

    print(f"  2月1日初始储能: {E_init:.2f} kWh")

    # 5. 逐天求解2月-12月（滚动优化）
    print("\n[5/7] 开始滚动优化...")
    results_all_days = []

    for i in range(n_days):
        date = dates[i]

        if (i + 1) % 30 == 0 or i == 0:
            elapsed = time.time() - start_time
            avg_time = elapsed / (i + 1 + start_idx)
            remaining_time = avg_time * (n_days - i - 1)
            print(f"  进度: {i+1}/{n_days} ({(i+1)/n_days*100:.1f}%) - {date.strftime('%Y-%m-%d')} - 预计剩余: {remaining_time/60:.1f}分钟")

        # 当天真实数据（仅用于 greedy 仿真，不用于优化决策）
        load_actual = load_data[i]    # (144,) 真实负载
        pv_actual   = pv_data[i]      # (144,) 真实光伏

        # ── 第一步：0:00 根据预报制定全天计划 ──────────────────────
        forecast_0h = forecasts.get(date, {}).get('0:00')
        if forecast_0h is None:
            print(f"  警告: {date.strftime('%Y-%m-%d')} 缺少0:00预报，跳过")
            continue

        # 当天 ARIMA 负载预报（用于优化决策）
        fc_idx = fc_date_map.get(pd.Timestamp(date).normalize())
        load_fc = load_actual if fc_idx is None else fc_load[fc_idx]

        planned_result = optimizer.solve_planned(price, load_fc, forecast_0h, E_init)
        if planned_result is None:
            print(f"  警告: {date.strftime('%Y-%m-%d')} 计划优化失败")
            continue

        # P_final：当前最优购电计划，随滚动调整更新
        P_final = planned_result['P_plan'].copy()

        # 全天结果数组（由 greedy 仿真逐段填充）
        P_charge_final    = np.zeros(144)
        P_discharge_final = np.zeros(144)
        P_emergency_final = np.zeros(144)
        E_storage_final   = np.zeros(145)
        E_storage_final[0] = E_init

        # 各调整步骤 breach/excess 费用累加
        total_breach_cost   = 0.0
        total_excess_cost   = 0.0

        # ── 第二步：greedy 仿真 0:00→6:00（P_buy 锁定为计划值）──
        seg = greedy_simulate(pv_actual, load_actual, P_final, E_init, 0, 36, optimizer)
        P_charge_final[0:36]    = seg['P_charge']
        P_discharge_final[0:36] = seg['P_discharge']
        P_emergency_final[0:36] = seg['P_emergency']
        E_storage_final[0:37]   = seg['E_storage']

        # ── 第三步：6:00/12:00/18:00 滚动调整 + greedy 仿真 ──────
        # (period_start, forecast_key, remaining_hours, seg_end)
        adjustment_steps = [
            (36,  '6:00',  18, 72),
            (72,  '12:00', 12, 108),
            (108, '18:00', 6,  144),
        ]

        for period_start, time_str, remaining_hours, seg_end in adjustment_steps:
            current_E = E_storage_final[period_start]  # 来自 greedy 仿真的真实 SOC

            forecast_t = forecasts.get(date, {}).get(time_str)
            if forecast_t is not None:
                # 将整点预报插值为 10 分钟值（仅取当天剩余小时）
                pv_fc_rem = partial_hourly_to_10min(
                    forecast_t[:remaining_hours], remaining_hours
                )  # shape: (remaining_hours*6,) = (remaining_periods,)

                # 调整剩余时段购电计划（使用预报，无数据泄漏）
                adjusted_result = optimizer.solve_adjusted(
                    price,
                    load_fc[period_start:],   # ARIMA 负载预报（剩余时段）
                    pv_fc_rem,                 # 光伏预报（剩余时段，已插值）
                    P_final,                   # 上一步计划（违约/超出基准）
                    current_E,
                    period_start
                )
                if adjusted_result is not None:
                    P_final[period_start:] = adjusted_result['P_adjusted']
                    total_breach_cost += adjusted_result['breach_cost']
                    total_excess_cost  += adjusted_result['excess_cost']

            # greedy 仿真本时段（使用更新后的 P_final 和真实数据）
            seg = greedy_simulate(
                pv_actual, load_actual, P_final,
                current_E, period_start, seg_end, optimizer
            )
            P_charge_final[period_start:seg_end]      = seg['P_charge']
            P_discharge_final[period_start:seg_end]   = seg['P_discharge']
            P_emergency_final[period_start:seg_end]   = seg['P_emergency']
            E_storage_final[period_start:seg_end + 1] = seg['E_storage']

        # ── 费用计算 ─────────────────────────────────────────────
        # 计划购电费（0:00 时刻计划，用于"计划购电量"表格报告）
        total_cost_plan = float(np.sum(planned_result['P_plan'] * price * (1.0 / 6)))

        adj_breach = total_breach_cost
        adj_excess = total_excess_cost

        cost_0_6 = np.sum(planned_result['P_plan'][:36] * price[:36] * (1/6))
        cost_6_24 = np.sum(P_final[36:] * price[36:] * (1/6))
        emergency_cost_sim = np.sum(P_emergency_final * price * optimizer.EMERGENCY_RATIO * optimizer.DELTA_T)
        total_cost_final = cost_0_6 + cost_6_24 + adj_excess - adj_breach + emergency_cost_sim
        total_emergency_cost = float(emergency_cost_sim)

        result_day = {
            'date': date,
            'P_plan': planned_result['P_plan'],
            'P_final': P_final,
            'P_charge': planned_result['P_charge'],
            'P_discharge': planned_result['P_discharge'],
            'P_charge_final': P_charge_final,
            'P_discharge_final': P_discharge_final,
            'E_storage': planned_result['E_storage'],
            'E_storage_final': E_storage_final,
            'P_emergency': P_emergency_final,
            'total_cost': total_cost_plan,
            'total_cost_final': total_cost_final,
            'adjustment_costs': {
                'breach': total_breach_cost,
                'excess': total_excess_cost,
                'emergency': total_emergency_cost,
            }
        }

        results_all_days.append(result_day)

        # 下一天初始 SOC = 今天 greedy 仿真最终 SOC
        E_init = E_storage_final[-1]

    print(f"\n  完成优化: {len(results_all_days)}/{n_days} 天")

    total_time = time.time() - start_time
    print(f"  总计算时间: {total_time/60:.1f} 分钟")

    # 6. 保存结果
    print("\n[6/7] 保存结果...")
    template_path = Path(template_dir) / "result3.xlsx"
    output_path = Path(output_dir) / "result3.xlsx"

    save_problem3_results(results_all_days, output_path, template_path)

    # 7. 统计汇总
    print("\n[7/7] 结果汇总")
    print("=" * 60)

    total_cost = sum([r['total_cost_final'] for r in results_all_days])
    total_purchase = sum([np.sum(r['P_final'] * (1/6)) for r in results_all_days])

    print(f"  总购电费用: {total_cost:.2f} 元")
    print(f"  总购电量: {total_purchase:.2f} kWh")
    print(f"  平均日购电费用: {total_cost/len(results_all_days):.2f} 元/天")

    # 打印指定日期的结果
    specified_dates = ['2025-03-20', '2025-06-21', '2025-09-23', '2025-12-21']
    print("\n指定日期的结果:")
    print("-" * 60)

    for date_str in specified_dates:
        target_date = pd.Timestamp(date_str)
        matching_results = [r for r in results_all_days if r['date'] == target_date]

        if matching_results:
            result = matching_results[0]
            purchase_kwh = np.sum(result['P_final'] * (1/6))
            print(f"  {date_str}:")
            print(f"    购电量: {purchase_kwh:.2f} kWh")
            print(f"    购电费: {result['total_cost_final']:.2f} 元")

    return results_all_days


if __name__ == "__main__":
    # 设置路径
    current_dir = Path(__file__).parent.parent
    data_dir = current_dir / "附件"
    output_dir = current_dir / "results"
    template_dir = current_dir / "附件" / "附件5"

    # 确保输出目录存在
    output_dir.mkdir(exist_ok=True)

    # 检查是否为测试模式
    test_mode = '--test' in sys.argv

    # 求解问题3
    results = solve_problem3(data_dir, output_dir, template_dir, test_mode=test_mode)

    if results:
        print("\n问题3求解完成！")
    else:
        print("\n问题3求解失败！")
