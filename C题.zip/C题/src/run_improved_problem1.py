"""
问题1：典型日优化（改进模型）
"""
import sys
import numpy as np
from pathlib import Path

sys.path.append(str(Path(__file__).parent))

from data_loader import DataLoader
from optimizer_improved_p2 import ImprovedProblem2Optimizer
from result_saver import save_problem1_results_v2


def solve_problem1(data_dir, output_dir, template_dir):
    loader = DataLoader(data_dir)
    data = loader.load_attachment1()

    price = data['price']
    load = data['load']
    pv_forecast = data['pv_forecast']

    optimizer = ImprovedProblem2Optimizer()
    # 问题1为典型日，强制要求终态储能回到初始值6000kWh，不需要终态价值激励
    results = optimizer.solve(price, load, pv_forecast, E_init=6000,
                              terminal_soc_weight=0.0, E_terminal=6000)

    if results is None:
        print("优化失败！")
        return None

    print(f"总购电费: {results['total_cost']:.2f} 元")

    template_path = Path(template_dir) / "result1.xlsx"
    output_path = Path(output_dir) / "result1_improved.xlsx"
    save_problem1_results_v2(results, output_path, template_path)
    print(f"结果已保存: {output_path}")

    return results


if __name__ == "__main__":
    base = Path(__file__).parent.parent
    results = solve_problem1(base / "附件", base / "results", base / "附件" / "附件5")
    if results:
        print("✓ 问题1求解完成")
    else:
        print("✗ 问题1求解失败")
