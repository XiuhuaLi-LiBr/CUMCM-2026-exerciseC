"""
改进的问题2优化器
支持紧急购电和光伏直充储能
"""

import pulp
import numpy as np


class ImprovedProblem2Optimizer:
    """改进的问题2优化器"""

    def __init__(self):
        """初始化优化器参数"""
        # 储能设备参数
        self.E_MAX_CAP = 12000  # 最大容量 (kWh)
        self.E_MIN = 1200       # 运行下限 (kWh)
        self.E_MAX = 10800      # 运行上限 (kWh)
        self.P_MAX = 5000       # 最大充放电功率 (kW)
        self.ETA_CH = 0.9       # 充电效率
        self.ETA_DIS = 0.9      # 放电效率

        # 时间参数
        self.DELTA_T = 1/6      # 时间间隔 (小时)
        self.T_PERIODS = 144    # 时间段数

        # 紧急购电价格倍数
        self.EMERGENCY_MULTIPLIER = 5

    def solve(self, price, load, pv_forecast, E_init, solver_name='PULP_CBC_CMD',
              terminal_soc_weight=None, E_terminal=None):
        """
        计划阶段（0:00决策）：基于预测光伏/负载制定当天计划购电量 P_buy。

        0:00时看不到当天真实数据，故目标函数中不含紧急购电惩罚——
        优化器只对预测场景最小化购电成本，紧急购电的实际发生由
        solve_execution() 在执行阶段用真实数据计算。

        Args:
            price:       电价数组 (144,)
            load:        预测负载数组 (144,)
            pv_forecast: 预测光伏数组 (144,)
            E_init:      初始储能 (kWh)
            solver_name: 求解器名称
            terminal_soc_weight: 终态储能价值权重（元/kWh），None 则自动估算
            E_terminal:  若非 None，强制终态储能等于该值

        Returns:
            dict: 含 P_buy (144,) 等计划结果
        """
        model = pulp.LpProblem("Planning", pulp.LpMinimize)

        # 决策变量
        P_buy       = [pulp.LpVariable(f"P_buy_{t}",  lowBound=0) for t in range(self.T_PERIODS)]
        P_charge    = [pulp.LpVariable(f"P_ch_{t}",   lowBound=0, upBound=self.P_MAX) for t in range(self.T_PERIODS)]
        P_discharge = [pulp.LpVariable(f"P_dis_{t}",  lowBound=0, upBound=self.P_MAX) for t in range(self.T_PERIODS)]
        E_storage   = [pulp.LpVariable(f"E_st_{t}",   lowBound=self.E_MIN, upBound=self.E_MAX) for t in range(self.T_PERIODS + 1)]
        delta_ch    = [pulp.LpVariable(f"dch_{t}",    cat='Binary') for t in range(self.T_PERIODS)]
        delta_dis   = [pulp.LpVariable(f"ddis_{t}",   cat='Binary') for t in range(self.T_PERIODS)]
        P_pv_to_storage = [pulp.LpVariable(f"pvs_{t}", lowBound=0) for t in range(self.T_PERIODS)]
        P_pv_to_load    = [pulp.LpVariable(f"pvl_{t}", lowBound=0) for t in range(self.T_PERIODS)]

        # 终态储能价值权重：存1kWh电的价值 ≈ 明天凌晨充回所需成本
        if terminal_soc_weight is None:
            terminal_soc_weight = float(np.mean(price[:36]) / self.ETA_CH)

        # 目标函数：最小化计划购电费用 - 终态储能价值
        # 注意：此处不含紧急购电，因为0:00看不到当天真实数据
        model += (
            pulp.lpSum(price[t] * P_buy[t] * self.DELTA_T for t in range(self.T_PERIODS))
            - terminal_soc_weight * E_storage[self.T_PERIODS]
        )

        for t in range(self.T_PERIODS):
            # 光伏分配约束（使用预测光伏）
            model += (P_pv_to_load[t] + P_pv_to_storage[t] <= pv_forecast[t], f"pv_split_{t}")

            # 功率平衡约束（无紧急购电：预测场景下计划购电需覆盖所有需求）
            # 购电 + 光伏供负载 + 放电 >= 负载 + 充电 - 光伏直充
            model += (
                P_buy[t] + P_pv_to_load[t] + P_discharge[t] >=
                load[t] + P_charge[t] - P_pv_to_storage[t],
                f"power_balance_{t}"
            )

            # 储能动态约束（P_charge 为充电侧总功率，含光伏直充）
            model += (
                E_storage[t + 1] == E_storage[t]
                + P_charge[t] * self.ETA_CH * self.DELTA_T
                - P_discharge[t] / self.ETA_DIS * self.DELTA_T,
                f"storage_dynamics_{t}"
            )

            # 充放电互斥约束
            model += (P_charge[t]    <= self.P_MAX * delta_ch[t],  f"charge_limit_{t}")
            model += (P_discharge[t] <= self.P_MAX * delta_dis[t], f"discharge_limit_{t}")
            model += (delta_ch[t] + delta_dis[t] <= 1,              f"mutex_{t}")

            # 光伏直充只能在充电模式下
            model += (P_pv_to_storage[t] <= self.P_MAX * delta_ch[t], f"pv_charge_limit_{t}")

        # 边界条件
        model += (E_storage[0] == E_init, "initial_storage")
        if E_terminal is not None:
            model += (E_storage[self.T_PERIODS] == E_terminal, "terminal_storage")

        # 求解
        solver = pulp.getSolver(solver_name, msg=0, timeLimit=300)
        model.solve(solver)

        if model.status != pulp.LpStatusOptimal:
            return None

        P_buy_arr = np.array([pulp.value(P_buy[t]) or 0.0 for t in range(self.T_PERIODS)])

        return {
            'P_buy':           P_buy_arr,
            'P_charge':        np.array([pulp.value(P_charge[t])    or 0.0 for t in range(self.T_PERIODS)]),
            'P_discharge':     np.array([pulp.value(P_discharge[t]) or 0.0 for t in range(self.T_PERIODS)]),
            'E_storage':       np.array([pulp.value(E_storage[t])   or 0.0 for t in range(self.T_PERIODS + 1)]),
            'P_pv_to_storage': np.array([pulp.value(P_pv_to_storage[t]) or 0.0 for t in range(self.T_PERIODS)]),
            'P_pv_to_load':    np.array([pulp.value(P_pv_to_load[t])    or 0.0 for t in range(self.T_PERIODS)]),
            # 计划费用（不含紧急购电，仅供参考）
            'planned_cost':    float(np.sum(price * P_buy_arr * self.DELTA_T)),
            'E_buy':           P_buy_arr * self.DELTA_T,
            'total_purchase':  float(np.sum(P_buy_arr * self.DELTA_T)),
            'status':          model.status,
        }


    def simulate_execution(self, price, load, pv_actual, E_init, P_buy_plan):
        """
        执行阶段（规则仿真，无优化）：
        P_buy 已在0:00锁定，逐时段按确定性规则模拟实际调度：
          1. 计算本时段可用电力 = P_buy_plan[t] + pv_actual[t]
          2. 优先满足负载；多余电力尽量充入储能（不超过 P_MAX 和 E_MAX）
          3. 若可用 + 储能放电仍不足负载，触发紧急购电补足

        没有优化求解器，只有逐时段顺序计算。

        Args:
            price:       电价数组 (144,)
            load:        真实负载数组 (144,)
            pv_actual:   真实光伏数组 (144,)
            E_init:      初始储能 (kWh)
            P_buy_plan:  计划购电功率 (144,)，单位 kW

        Returns:
            dict: 执行结果
        """
        T = self.T_PERIODS
        P_buy_arr = np.array(P_buy_plan, dtype=float)

        P_ch_arr  = np.zeros(T)
        P_dis_arr = np.zeros(T)
        P_emg_arr = np.zeros(T)
        pvs_arr   = np.zeros(T)   # 光伏→储能
        pvl_arr   = np.zeros(T)   # 光伏→负载
        E_arr     = np.zeros(T + 1)
        E_arr[0]  = E_init

        for t in range(T):
            E_cur   = E_arr[t]
            pb      = P_buy_arr[t]
            pv      = float(pv_actual[t])
            ld      = float(load[t])

            # ── 步骤1：总供给（购电 + 光伏）vs 负载 ────────────────
            supply  = pb + pv
            surplus = supply - ld   # >0 富余，<0 缺口

            if surplus >= 0:
                # ── 富余：先用光伏和购电满足负载，剩余尽量充储能 ──
                # 光伏尽量直接供负载
                pv_to_load   = min(pv, ld)
                pv_remaining = pv - pv_to_load   # 负载满足后的剩余光伏

                # 可充入储能的总富余功率
                charge_avail = surplus            # = pb + pv - ld
                charge_cap   = min(self.P_MAX,
                                   (self.E_MAX - E_cur) / (self.ETA_CH * self.DELTA_T))
                charge_cap   = max(0.0, charge_cap)
                p_charge     = min(charge_avail, charge_cap)

                # 光伏直充部分（不超过 pv_remaining 和 p_charge）
                pv_to_storage = min(pv_remaining, p_charge)
                # 其余充电来自购电（隐含）

                pvl_arr[t]  = pv_to_load
                pvs_arr[t]  = pv_to_storage
                P_ch_arr[t] = p_charge
                P_dis_arr[t] = 0.0
                P_emg_arr[t] = 0.0

            else:
                # ── 缺口：先从储能放电补足 ──────────────────────────
                deficit = -surplus   # 需要额外补充的功率

                # 光伏全部供负载（pv < ld）
                pvl_arr[t]    = pv
                pvs_arr[t]    = 0.0
                P_ch_arr[t]   = 0.0

                discharge_cap = min(self.P_MAX,
                                    (E_cur - self.E_MIN) * self.ETA_DIS / self.DELTA_T)
                discharge_cap = max(0.0, discharge_cap)
                p_discharge   = min(deficit, discharge_cap)
                P_dis_arr[t]  = p_discharge

                remaining_deficit = deficit - p_discharge
                P_emg_arr[t]  = max(0.0, remaining_deficit)

            # ── 储能状态更新 ─────────────────────────────────────────
            E_arr[t + 1] = (E_cur
                            + P_ch_arr[t]  * self.ETA_CH  * self.DELTA_T
                            - P_dis_arr[t] / self.ETA_DIS * self.DELTA_T)
            # 截断到合法范围（浮点误差保护）
            E_arr[t + 1] = float(np.clip(E_arr[t + 1], self.E_MIN, self.E_MAX))

        planned_cost   = float(np.sum(price * P_buy_arr * self.DELTA_T))
        emergency_cost = float(np.sum(
            self.EMERGENCY_MULTIPLIER * price * P_emg_arr * self.DELTA_T))

        return {
            'P_buy':           P_buy_arr,
            'P_emergency':     P_emg_arr,
            'P_charge':        P_ch_arr,
            'P_discharge':     P_dis_arr,
            'E_storage':       E_arr,
            'P_pv_to_storage': pvs_arr,
            'P_pv_to_load':    pvl_arr,
            'E_buy':           P_buy_arr * self.DELTA_T,
            'E_emergency':     P_emg_arr * self.DELTA_T,
            'total_purchase':  float(np.sum(P_buy_arr * self.DELTA_T)
                                     + np.sum(P_emg_arr * self.DELTA_T)),
            'planned_cost':    planned_cost,
            'emergency_cost':  emergency_cost,
            'total_cost':      planned_cost + emergency_cost,
        }


if __name__ == "__main__":
    print("改进的问题2优化器已创建")
