"""
问题4-2：使用波动电价（附件4）重做问题2（两阶段模式）

计划阶段：用 ARIMA 预测电价（forecasts_p4.npz）+ 预测光伏/负载（forecasts_p2.npz）
执行阶段：用附件4真实电价 + 附件2真实光伏/负载

预测文件分别由 precompute_forecasts_p4.py 和 precompute_forecasts.py 生成，运行一次即可。
"""

import sys
import warnings
import numpy as np
import pandas as pd
from pathlib import Path
import time

warnings.filterwarnings('ignore')

sys.path.append(str(Path(__file__).parent))

from data_loader import DataLoader
from optimizer_improved_p2 import ImprovedProblem2Optimizer
from result_saver import save_problem2_results_v2


def load_price_forecasts(forecast_path):
    """
    读取预计算的波动电价预测结果。

    Returns:
        price_forecast : (334, 144) ndarray
        dates          : (334,) list of pd.Timestamp
    """
    data = np.load(forecast_path, allow_pickle=True)
    price_forecast = data['price_forecast']   # (334, 144)
    dates = [pd.Timestamp(d) for d in data['dates']]
    return price_forecast, dates


def load_pv_load_forecasts(forecast_path):
    """
    读取预计算的光伏/负载预测结果（来自 forecasts_p2.npz）。

    Returns:
        pv_forecast   : (334, 144) ndarray
        load_forecast : (334, 144) ndarray
        dates         : (334,) list of pd.Timestamp
    """
    data = np.load(forecast_path, allow_pickle=True)
    pv_forecast   = data['pv_forecast']    # (334, 144)
    load_forecast = data['load_forecast']  # (334, 144)
    dates = [pd.Timestamp(d) for d in data['dates']]
    return pv_forecast, load_forecast, dates


def solve_problem4_2(data_dir, output_dir, template_dir, forecast_path,
                     pv_load_forecast_path=None, test_mode=False):
    """
    使用改进模型求解问题4-2（两阶段：计划用预测电价+预测光伏/负载，执行用真实数据）

    Args:
        data_dir:              附件数据目录
        output_dir:            结果输出目录
        template_dir:          Excel 模板目录
        forecast_path:         预计算电价预测文件路径（forecasts_p4.npz）
        pv_load_forecast_path: 预计算光伏/负载预测文件路径（forecasts_p2.npz），
                               None 时计划阶段也使用真实光伏/负载
        test_mode:             True 时只跑前5天
    """
    print("=" * 60)
    print("问题4-2：波动电价 + 两阶段改进模型优化（334天）")
    print("=" * 60)

    start_time = time.time()

    # ── 1. 加载数据 ──────────────────────────────────────────
    print("\n[1/6] 加载数据...")
    loader = DataLoader(data_dir)

    # 附件4波动电价（真实值，执行阶段使用）
    data4 = loader.load_attachment4()
    price_all = data4['prices']   # (365, 144)
    print(f"  波动电价数据: {price_all.shape}  均值={price_all.mean():.4f} 元/kWh")

    # 附件2光伏 + 负载（真实值，执行阶段使用）
    data2 = loader.load_attachment2()
    load_all  = data2['load']        # (365, 144)
    pv_all    = data2['pv_actual']   # (365, 144)
    dates_all = data2['dates']

    print(f"  负载数据: {load_all.shape}")
    print(f"  光伏数据: {pv_all.shape}")

    # ── 2. 读取预计算电价预测 ─────────────────────────────────
    print("\n[2/6] 读取预计算预测（forecasts_p4.npz + forecasts_p2.npz）...")
    forecast_path = Path(forecast_path)
    if not forecast_path.exists():
        raise FileNotFoundError(
            f"预测文件不存在: {forecast_path}\n"
            "请先运行 python src/precompute_forecasts_p4.py"
        )
    price_fc, forecast_dates = load_price_forecasts(forecast_path)
    print(f"  price_forecast shape: {price_fc.shape}")
    print(f"  日期范围: {forecast_dates[0].strftime('%Y-%m-%d')} "
          f"~ {forecast_dates[-1].strftime('%Y-%m-%d')}")

    # 读取光伏/负载预测（来自问题2预计算结果）
    p2_fc_path = Path(pv_load_forecast_path) if pv_load_forecast_path else None
    if p2_fc_path is None:
        p2_fc_path = forecast_path.parent / "forecasts_p2.npz"
    if not p2_fc_path.exists():
        raise FileNotFoundError(
            f"光伏/负载预测文件不存在: {p2_fc_path}\n"
            "请先运行 python src/precompute_forecasts.py"
        )
    pv_fc, load_fc, _ = load_pv_load_forecasts(p2_fc_path)
    print(f"  pv_forecast   shape: {pv_fc.shape}")
    print(f"  load_forecast shape: {load_fc.shape}")

    # ── 3. 确定优化范围 ───────────────────────────────────────
    print("\n[3/6] 确定优化范围...")
    start_date = pd.Timestamp('2025-02-01')
    start_idx  = int(np.where(dates_all == start_date)[0][0])
    n_days     = len(dates_all) - start_idx   # 334

    if test_mode:
        n_days = 5

    assert len(forecast_dates) >= n_days, \
        f"预测天数({len(forecast_dates)})少于优化天数({n_days})"

    print(f"  优化范围: 2025-02-01 起 {'测试' if test_mode else '完整'} {n_days} 天")

    # ── 4. 创建优化器 ─────────────────────────────────────────
    print("\n[4/6] 创建改进优化器...")
    optimizer = ImprovedProblem2Optimizer()

    # ── 5. 优化1月（推算2月1日初始储能，不计入输出）────────────
    print("\n[5/6] 优化1月份（结果不计入输出）...")
    E_init = 6000.0   # 2025-01-01 初始储能 kWh

    for day_idx in range(start_idx):
        if (day_idx + 1) % 10 == 0:
            print(f"    1月进度: {day_idx+1}/{start_idx}")

        price_jan = price_all[day_idx]
        load_jan  = load_all[day_idx]
        pv_jan    = pv_all[day_idx]

        result = optimizer.solve(price_jan, load_jan, pv_jan, E_init)
        if result:
            E_init = result['E_storage'][-1]
        else:
            print(f"  警告: 1月第{day_idx+1}天优化失败")

    print(f"  2月1日初始储能: {E_init:.2f} kWh")

    # ── 6. 逐天两阶段优化（2月～12月）────────────────────────
    print("\n[6/6] 开始逐天两阶段优化（334天）...")
    results_all_days = []

    for i in range(n_days):
        day_idx = start_idx + i
        date    = dates_all.iloc[day_idx]

        if (i + 1) % 30 == 0 or i == 0:
            elapsed   = time.time() - start_time
            avg       = elapsed / (i + 1 + start_idx)
            remaining = avg * (n_days - i - 1)
            print(f"  进度: {i+1}/{n_days} ({(i+1)/n_days*100:.1f}%)"
                  f" - {date.strftime('%Y-%m-%d')}"
                  f" - 预计剩余: {remaining/60:.1f}分钟")

        price_forecast_today = price_fc[i]          # 预测电价（计划阶段）
        price_actual_today   = price_all[day_idx]   # 真实电价（执行阶段）
        load_forecast_today  = load_fc[i]           # 预测负载（计划阶段）
        pv_forecast_today    = pv_fc[i]             # 预测光伏（计划阶段）
        load_actual_today    = load_all[day_idx]    # 真实负载（执行阶段）
        pv_actual_today      = pv_all[day_idx]      # 真实光伏（执行阶段）

        # ── 阶段1：计划（预测电价 + 预测光伏/负载）──────────────
        plan = optimizer.solve(price_forecast_today, load_forecast_today, pv_forecast_today, E_init)
        if plan is None:
            print(f"  警告: {date.strftime('%Y-%m-%d')} 计划阶段失败，跳过")
            continue
        P_buy_plan = plan['P_buy']

        # ── 阶段2：执行（真实电价+真实光伏/负载，P_buy 锁定计划值）──
        result = optimizer.simulate_execution(
            price_actual_today, load_actual_today, pv_actual_today, E_init, P_buy_plan)
        if result is None:
            print(f"  警告: {date.strftime('%Y-%m-%d')} 执行阶段失败，跳过")
            continue

        result['date'] = date
        results_all_days.append(result)

        # 用执行阶段的真实终态储能更新下一天初值
        E_init = result['E_storage'][-1]

    print(f"\n  完成优化: {len(results_all_days)}/{n_days} 天")
    print(f"  总计算时间: {(time.time()-start_time)/60:.1f} 分钟")

    # ── 保存结果 ──────────────────────────────────────────────
    print("\n保存结果...")
    template_path = Path(template_dir) / "result2.xlsx"
    output_path   = Path(output_dir) / "result4-2.xlsx"
    save_problem2_results_v2(results_all_days, output_path, template_path)
    print(f"  结果已保存到: {output_path}")

    # ── 统计汇总 ──────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("结果汇总")
    print("=" * 60)

    total_cost           = sum(r['total_cost']     for r in results_all_days)
    total_planned_cost   = sum(r.get('planned_cost',   r['total_cost'])   for r in results_all_days)
    total_emergency_cost = sum(r['emergency_cost'] for r in results_all_days)
    total_purchase       = sum(r['total_purchase'] for r in results_all_days)
    emergency_days       = sum(1 for r in results_all_days if np.sum(r['P_emergency']) > 1e-6)

    print(f"  总购电费用:       {total_cost:.2f} 元")
    print(f"    其中计划购电费: {total_planned_cost:.2f} 元")
    print(f"    其中紧急购电费: {total_emergency_cost:.2f} 元")
    print(f"  总购电量:         {total_purchase:.2f} kWh")
    print(f"  紧急购电天数:     {emergency_days}/{len(results_all_days)} 天")
    print(f"  平均日购电费用:   {total_cost/len(results_all_days):.2f} 元/天")

    # 对比问题2（固定电价）
    p2_cost = 12408855.12
    diff = total_cost - p2_cost
    print(f"\n  对比问题2（固定电价）: {p2_cost:.2f} 元")
    print(f"  问题4-2费用: {total_cost:.2f} 元  差值: {diff:+.2f} 元")

    specified_dates = ['2025-03-20', '2025-06-21', '2025-09-23', '2025-12-21']
    print("\n指定日期结果:")
    print("-" * 60)
    for ds in specified_dates:
        target = pd.Timestamp(ds)
        matched = [r for r in results_all_days if r['date'] == target]
        if matched:
            r = matched[0]
            pv_to_storage = np.sum(r['P_pv_to_storage'] * (1/6))
            print(f"  {ds}:")
            print(f"    购电量: {r['total_purchase']:.2f} kWh  "
                  f"购电费: {r['total_cost']:.2f} 元  "
                  f"光伏充储: {pv_to_storage:.2f} kWh")
            if r['emergency_cost'] > 0:
                print(f"    紧急购电费: {r['emergency_cost']:.2f} 元")

    return results_all_days


if __name__ == "__main__":
    current_dir   = Path(__file__).parent.parent
    data_dir      = current_dir / "附件"
    output_dir    = current_dir / "results"
    template_dir  = current_dir / "附件" / "附件5"
    forecast_path = current_dir / "results" / "forecasts_p4.npz"

    output_dir.mkdir(exist_ok=True)

    import sys as _sys
    test_mode = '--test' in _sys.argv
    results = solve_problem4_2(data_dir, output_dir, template_dir, forecast_path, test_mode=test_mode)

    if results:
        print("\n问题4-2（两阶段版）求解完成！")
    else:
        print("\n问题4-2（两阶段版）求解失败！")
