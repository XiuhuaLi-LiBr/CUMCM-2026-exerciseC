"""
预计算2月1日至12月31日（334天）的逐日光伏/负载预测
预测模型：SARIMA(1,0,0)(1,0,0)[7]，逐时间槽独立建模
结果保存到 results/forecasts_p2.npz，优化时直接读取

运行一次即可；后续 run_improved_problem2.py 不再重复建模
"""

import sys
import warnings
import numpy as np
import pandas as pd
from pathlib import Path
import time

warnings.filterwarnings('ignore')

sys.path.append(str(Path(__file__).parent))
from data_loader import DataLoader


# ──────────────────────────────────────────────
# 核心预测函数
# ──────────────────────────────────────────────

def sarima_forecast_series(history, k_recent=30, night_threshold=1.0):
    """
    对形状为 (n_days, 144) 的历史数组，预测"明天"各时段值。

    Args:
        history:         (n_days, 144) 历史数据（实际值）
        k_recent:        取最近多少天建模，默认30
        night_threshold: 低于此值的时段（夜间光伏）直接预测为0；
                         设为 None 则对所有时段建模（用于负载）

    Returns:
        (144,) 预测数组，非负
    """
    from statsmodels.tsa.statespace.sarimax import SARIMAX

    n = min(k_recent, len(history))
    recent = history[-n:]          # (n, 144)
    forecast = np.zeros(144)

    for t in range(144):
        series = recent[:, t]

        # 光伏夜间时段全为0，跳过建模
        if night_threshold is not None and series.max() < night_threshold:
            forecast[t] = 0.0
            continue

        try:
            model = SARIMAX(series,
                            order=(1, 0, 0),
                            seasonal_order=(1, 0, 0, 7),
                            enforce_stationarity=False,
                            enforce_invertibility=False)
            res = model.fit(disp=False, maxiter=50)
            pred = res.forecast(steps=1)[0]
            forecast[t] = max(0.0, pred)
        except Exception:
            # 拟合失败退化为近7天均值
            forecast[t] = max(0.0, float(np.mean(series[-7:])))

    return forecast


# ──────────────────────────────────────────────
# 主流程
# ──────────────────────────────────────────────

def precompute(data_dir, output_path, k_recent=30):
    print("=" * 60)
    print("预计算光伏 & 负载 SARIMA 预测（334天）")
    print("=" * 60)

    # 1. 加载数据
    print("\n[1/3] 加载附件2数据...")
    loader = DataLoader(data_dir)
    data2 = loader.load_attachment2()
    load_all  = data2['load']        # (365, 144)
    pv_all    = data2['pv_actual']   # (365, 144)
    dates_all = data2['dates']       # pandas Series of Timestamp

    # 2. 确定日期范围：2月1日起
    start_date = pd.Timestamp('2025-02-01')
    start_idx  = np.where(dates_all == start_date)[0][0]   # 31
    n_days     = len(dates_all) - start_idx                 # 334
    dates_feb_dec = dates_all[start_idx:].reset_index(drop=True)

    print(f"  1月共 {start_idx} 天作为初始历史")
    print(f"  需预测 {n_days} 天（{dates_feb_dec.iloc[0].strftime('%Y-%m-%d')} "
          f"~ {dates_feb_dec.iloc[-1].strftime('%Y-%m-%d')}）")

    # 3. 逐天预计算
    print("\n[2/3] 开始逐天预测（每天144个时间槽 × 2个序列）...")
    pv_forecasts   = np.zeros((n_days, 144))
    load_forecasts = np.zeros((n_days, 144))

    t0 = time.time()

    for i in range(n_days):
        # 截至昨天的历史（第 i 天预测用 i 天前的所有数据）
        history_end = start_idx + i       # 不含当天
        pv_hist   = pv_all[:history_end]   # (history_end, 144)
        load_hist = load_all[:history_end]

        # 光伏预测（夜间直接=0）
        pv_forecasts[i] = sarima_forecast_series(
            pv_hist, k_recent=k_recent, night_threshold=1.0)

        # 负载预测（不跳过任何时段）
        load_forecasts[i] = sarima_forecast_series(
            load_hist, k_recent=k_recent, night_threshold=None)

        # 进度
        if (i + 1) % 10 == 0 or i == 0:
            elapsed   = time.time() - t0
            avg       = elapsed / (i + 1)
            remaining = avg * (n_days - i - 1)
            date_str  = dates_feb_dec.iloc[i].strftime('%Y-%m-%d')
            print(f"  [{i+1:3d}/{n_days}] {date_str}  "
                  f"耗时 {elapsed/60:.1f}min  预计剩余 {remaining/60:.1f}min")

    # 4. 保存
    print("\n[3/3] 保存预测结果...")
    output_path = Path(output_path)
    output_path.parent.mkdir(exist_ok=True)

    date_strings = dates_feb_dec.dt.strftime('%Y-%m-%d').values

    np.savez_compressed(
        output_path,
        pv_forecast=pv_forecasts,       # (334, 144)
        load_forecast=load_forecasts,   # (334, 144)
        dates=date_strings,             # (334,) str
        start_idx=np.array(start_idx),
        k_recent=np.array(k_recent),
    )

    total = time.time() - t0
    print(f"  已保存到: {output_path}")
    print(f"  pv_forecast  shape: {pv_forecasts.shape}")
    print(f"  load_forecast shape: {load_forecasts.shape}")
    print(f"  总耗时: {total/60:.1f} 分钟")
    print("\n✓ 预计算完成！后续运行 run_improved_problem2.py 将直接读取此文件。")


if __name__ == "__main__":
    current_dir = Path(__file__).parent.parent
    data_dir    = current_dir / "附件"
    output_path = current_dir / "results" / "forecasts_p2.npz"

    precompute(data_dir, output_path, k_recent=30)
