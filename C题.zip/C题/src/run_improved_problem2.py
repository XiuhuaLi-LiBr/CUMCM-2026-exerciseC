"""
使用改进模型求解问题2（334天完整版）
光伏/负载预测：从 results/forecasts_p2.npz 读取预计算结果
（预计算由 precompute_forecasts.py 完成，运行一次即可）
"""

import sys
import warnings
import numpy as np
import pandas as pd
from pathlib import Path
import time

warnings.filterwarnings('ignore')

sys.path.append(str(Path(__file__).parent))
from data_loader import DataLoader
from optimizer_improved_p2 import ImprovedProblem2Optimizer
from result_saver import save_problem2_results_v2


def load_forecasts(forecast_path):
    """
    读取预计算的光伏/负载预测结果。

    Returns:
        pv_forecast   : (334, 144) ndarray
        load_forecast : (334, 144) ndarray
        dates         : (334,) list of pd.Timestamp
    """
    data = np.load(forecast_path, allow_pickle=True)
    pv_forecast   = data['pv_forecast']    # (334, 144)
    load_forecast = data['load_forecast']  # (334, 144)
    dates = [pd.Timestamp(d) for d in data['dates']]
    return pv_forecast, load_forecast, dates


def solve_problem2_improved(data_dir, output_dir, template_dir, forecast_path):
    """
    使用改进模型求解问题2（两阶段：计划用预测，执行用真实数据）

    Args:
        data_dir:      附件数据目录
        output_dir:    结果输出目录
        template_dir:  Excel 模板目录
        forecast_path: 预计算预测文件路径（forecasts_p2.npz）
    """
    print("=" * 60)
    print("问题2：改进模型全年优化（334天）")
    print("=" * 60)

    start_time = time.time()

    # ── 1. 加载数据 ──────────────────────────────────────────
    print("\n[1/6] 加载数据...")
    loader = DataLoader(data_dir)

    data1 = loader.load_attachment1()
    price = data1['price']          # (144,)

    data2 = loader.load_attachment2()
    load_all  = data2['load']        # (365, 144) 真实负载
    pv_all    = data2['pv_actual']   # (365, 144) 真实光伏
    dates_all = data2['dates']

    print(f"  电价: {len(price)} 个时段")
    print(f"  负载/光伏数据: {load_all.shape}")
    print(f"  日期范围: {dates_all.iloc[0]} 到 {dates_all.iloc[-1]}")

    # ── 2. 读取预计算预测 ─────────────────────────────────────
    print("\n[2/6] 读取预计算预测（forecasts_p2.npz）...")
    forecast_path = Path(forecast_path)
    if not forecast_path.exists():
        raise FileNotFoundError(
            f"预测文件不存在: {forecast_path}\n"
            "请先运行 python src/precompute_forecasts.py"
        )
    pv_fc, load_fc, forecast_dates = load_forecasts(forecast_path)
    print(f"  pv_forecast   shape: {pv_fc.shape}")
    print(f"  load_forecast shape: {load_fc.shape}")
    print(f"  日期范围: {forecast_dates[0].strftime('%Y-%m-%d')} "
          f"~ {forecast_dates[-1].strftime('%Y-%m-%d')}")

    # ── 3. 确定优化范围 ───────────────────────────────────────
    print("\n[3/6] 确定优化范围...")
    start_date = pd.Timestamp('2025-02-01')
    start_idx  = np.where(dates_all == start_date)[0][0]

    pv_data   = pv_all[start_idx:]    # (334, 144) 真实光伏（执行阶段用）
    load_data = load_all[start_idx:]  # (334, 144) 真实负载（执行阶段用）
    n_days    = len(pv_data)

    print(f"  优化日期: 2025-02-01 到 2025-12-31，共 {n_days} 天")
    assert len(forecast_dates) == n_days, \
        f"预测天数({len(forecast_dates)})与优化天数({n_days})不匹配"

    # ── 4. 创建优化器 ─────────────────────────────────────────
    print("\n[4/6] 创建改进优化器...")
    optimizer = ImprovedProblem2Optimizer()

    # ── 5. 优化1月（推算2月1日初始储能，不计入输出）────────────
    print("\n[5/6] 优化1月份（结果不计入输出）...")
    E_init = 6000.0  # 2025-01-01 初始储能 kWh

    for day_idx in range(start_idx):
        if (day_idx + 1) % 10 == 0:
            print(f"    1月进度: {day_idx+1}/{start_idx}")
        result = optimizer.solve(price, load_all[day_idx], pv_all[day_idx], E_init)
        if result:
            E_init = result['E_storage'][-1]
        else:
            print(f"  警告: 1月第{day_idx+1}天优化失败")

    print(f"  2月1日初始储能: {E_init:.2f} kWh")

    # ── 6. 逐天两阶段优化（2月～12月）────────────────────────
    print("\n[6/6] 开始逐天两阶段优化（334天）...")
    results_all_days = []

    for i, date in enumerate(forecast_dates):
        if (i + 1) % 30 == 0 or i == 0:
            elapsed   = time.time() - start_time
            avg       = elapsed / (i + 1 + start_idx)
            remaining = avg * (n_days - i - 1)
            print(f"  进度: {i+1}/{n_days} ({(i+1)/n_days*100:.1f}%)"
                  f" - {date.strftime('%Y-%m-%d')}"
                  f" - 预计剩余: {remaining/60:.1f}分钟")

        pv_forecast_today   = pv_fc[i]        # 0:00时刻的预测光伏
        load_forecast_today = load_fc[i]      # 0:00时刻的预测负载
        pv_actual_today     = pv_data[i]      # 当天真实光伏（执行阶段用）
        load_actual_today   = load_data[i]    # 当天真实负载（执行阶段用）

        # ── 阶段1：计划（预测数据） ──────────────────────────
        plan = optimizer.solve(price, load_forecast_today, pv_forecast_today, E_init)
        if plan is None:
            print(f"  警告: {date.strftime('%Y-%m-%d')} 计划阶段失败，跳过")
            continue
        P_buy_plan = plan['P_buy']

        # ── 阶段2：执行（真实数据，P_buy 锁定）──────────────
        result = optimizer.simulate_execution(
            price, load_actual_today, pv_actual_today, E_init, P_buy_plan)
        if result is None:
            print(f"  警告: {date.strftime('%Y-%m-%d')} 执行阶段失败，跳过")
            continue
        # simulate_execution 不会返回 None（纯规则仿真，始终成功）

        result['date'] = date
        results_all_days.append(result)

        # 用执行阶段的真实终态储能更新下一天初值
        E_init = result['E_storage'][-1]

    print(f"\n  完成优化: {len(results_all_days)}/{n_days} 天")
    print(f"  总计算时间: {(time.time()-start_time)/60:.1f} 分钟")

    # ── 保存结果 ──────────────────────────────────────────────
    print("\n保存结果...")
    template_path = Path(template_dir) / "result2.xlsx"
    output_path   = Path(output_dir) / "result2_improved.xlsx"
    save_problem2_results_v2(results_all_days, output_path, template_path)
    print(f"  结果已保存: {output_path}")

    # ── 统计汇总 ──────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("结果汇总")
    print("=" * 60)

    total_cost           = sum(r['total_cost']     for r in results_all_days)
    total_planned_cost   = sum(r['planned_cost']   for r in results_all_days)
    total_emergency_cost = sum(r['emergency_cost'] for r in results_all_days)
    total_purchase       = sum(r['total_purchase'] for r in results_all_days)
    emergency_days       = sum(1 for r in results_all_days if np.sum(r['P_emergency']) > 1e-6)

    print(f"  总购电费用:       {total_cost:.2f} 元")
    print(f"    其中计划购电费: {total_planned_cost:.2f} 元")
    print(f"    其中紧急购电费: {total_emergency_cost:.2f} 元")
    print(f"  总购电量:         {total_purchase:.2f} kWh")
    print(f"  紧急购电天数:     {emergency_days}/{len(results_all_days)} 天")
    print(f"  平均日购电费用:   {total_cost/len(results_all_days):.2f} 元/天")

    specified_dates = ['2025-03-20', '2025-06-21', '2025-09-23', '2025-12-21']
    print("\n指定日期结果:")
    print("-" * 60)
    for ds in specified_dates:
        target = pd.Timestamp(ds)
        matched = [r for r in results_all_days if r['date'] == target]
        if matched:
            r = matched[0]
            pv_to_storage = np.sum(r['P_pv_to_storage'] * (1/6))
            print(f"  {ds}:")
            print(f"    购电量: {r['total_purchase']:.2f} kWh  "
                  f"购电费: {r['total_cost']:.2f} 元  "
                  f"光伏充储: {pv_to_storage:.2f} kWh")
            if r['emergency_cost'] > 0:
                print(f"    紧急购电费: {r['emergency_cost']:.2f} 元")

    return results_all_days


if __name__ == "__main__":
    current_dir   = Path(__file__).parent.parent
    data_dir      = current_dir / "附件"
    output_dir    = current_dir / "results"
    template_dir  = current_dir / "附件" / "附件5"
    forecast_path = current_dir / "results" / "forecasts_p2.npz"

    output_dir.mkdir(exist_ok=True)

    results = solve_problem2_improved(data_dir, output_dir, template_dir, forecast_path)

    if results:
        print("\n✓ 问题2（改进版）求解完成！")
    else:
        print("\n✗ 问题2（改进版）求解失败！")
