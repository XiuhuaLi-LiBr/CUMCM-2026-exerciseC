"""
问题3优化器：带预报更新的购电策略优化
支持0:00计划购电 + 6:00/12:00/18:00调整购电
"""

import pulp
import numpy as np


class Problem3Optimizer:
    """
    问题3优化器：多次预报滚动优化

    特点：
    1. 0:00根据预报制定计划购电策略
    2. 6:00/12:00/18:00根据新预报调整购电策略
    3. 违约费用：计划 > 实际，差额按50%电价
    4. 超出费用：实际 > 计划，差额按150%电价
    5. 紧急购电：供电不足时按5倍电价
    """

    def __init__(self):
        # 储能参数
        self.E_MAX = 12000  # 最大容量 kWh
        self.E_MIN = 1200   # 最小容量 kWh
        self.E_UPPER = 10800  # 运行上限 kWh
        self.P_MAX = 5000   # 最大充放电功率 kW
        self.ETA_CH = 0.9   # 充电效率
        self.ETA_DIS = 0.9  # 放电效率

        # 时间参数
        self.T_PERIODS = 144  # 每天144个10分钟时段
        self.DELTA_T = 1/6    # 10分钟 = 1/6小时

        # 费用参数
        self.BREACH_RATIO = 0.5    # 违约比例：50%
        self.EXCESS_RATIO = 1.5    # 超出比例：150%
        self.EMERGENCY_RATIO = 5.0  # 紧急购电：5倍

    def hourly_to_10min(self, hourly_data):
        """
        将整点数据插值到10分钟间隔

        Args:
            hourly_data: 24小时整点数据

        Returns:
            144个10分钟数据
        """
        # 创建时间点
        hours = np.arange(25)  # 0-24小时
        minutes_10 = np.arange(0, 1440, 10) / 60  # 0-1440分钟转换为小时

        # 扩展hourly_data到25个点（加上24:00 = 0:00+1天）
        hourly_extended = np.append(hourly_data, hourly_data[-1])

        # 线性插值
        data_10min = np.interp(minutes_10, hours, hourly_extended)

        return data_10min[:144]  # 只取前144个（0:00-23:50）

    def solve_planned(self, price, load, pv_forecast_0h, E_init, solver_name='PULP_CBC_CMD',
                      terminal_soc_weight=None):
        """
        0:00时刻：根据预报制定全天计划购电策略

        Args:
            price: 电价数组 (144,)
            load: 负载数组 (144,)
            pv_forecast_0h: 0:00时刻的24小时光伏预报（整点）
            E_init: 初始储能 kWh
            solver_name: 求解器名称

        Returns:
            dict: {
                'P_plan': 计划购电功率 (144,)
                'P_charge': 充电功率 (144,)
                'P_discharge': 放电功率 (144,)
                'E_storage': 储能电量 (145,) - 包含初始和每个时段结束后
                'total_cost': 总费用（计划阶段）
                'status': 求解状态
            }
        """
        # 将整点预报插值到10分钟
        pv_forecast = self.hourly_to_10min(pv_forecast_0h)

        # 创建优化模型
        model = pulp.LpProblem("Problem3_Planned", pulp.LpMinimize)

        # 决策变量
        P_plan = [pulp.LpVariable(f"P_plan_{t}", lowBound=0) for t in range(self.T_PERIODS)]
        P_charge = [pulp.LpVariable(f"P_charge_{t}", lowBound=0, upBound=self.P_MAX)
                    for t in range(self.T_PERIODS)]
        P_discharge = [pulp.LpVariable(f"P_discharge_{t}", lowBound=0, upBound=self.P_MAX)
                       for t in range(self.T_PERIODS)]

        # 光伏分配
        P_pv_to_storage = [pulp.LpVariable(f"P_pv_storage_{t}", lowBound=0)
                          for t in range(self.T_PERIODS)]
        P_pv_to_load = [pulp.LpVariable(f"P_pv_load_{t}", lowBound=0)
                       for t in range(self.T_PERIODS)]

        # 储能状态
        E_storage = [pulp.LpVariable(f"E_storage_{t}", lowBound=self.E_MIN, upBound=self.E_UPPER)
                     for t in range(self.T_PERIODS + 1)]

        # 充放电互斥的二进制变量
        is_charging = [pulp.LpVariable(f"is_charging_{t}", cat='Binary')
                      for t in range(self.T_PERIODS)]

        # 终态储能价值权重：激励优化器为后一天留电
        # 含义：存1kWh电的价值 ≈ 明天凌晨重新充回所需成本
        # = 凌晨电价(0:00-6:00前36个时段均值) / 充电效率
        if terminal_soc_weight is None:
            terminal_soc_weight = float(np.mean(price[:36]) / self.ETA_CH)

        # 目标函数：最小化计划购电费用 - 终态储能价值
        total_cost = pulp.lpSum([P_plan[t] * self.DELTA_T * price[t] for t in range(self.T_PERIODS)]) \
                     - terminal_soc_weight * E_storage[self.T_PERIODS]
        model += total_cost

        # 约束条件
        # 1. 初始储能
        model += E_storage[0] == E_init

        for t in range(self.T_PERIODS):
            # 2. 光伏分配约束
            model += P_pv_to_load[t] + P_pv_to_storage[t] <= pv_forecast[t]

            # 3. 功率平衡约束（改进版：光伏直充储能）
            # P_discharge 为负载侧功率，P_charge 为 AC 侧充电功率，效率已在状态方程中体现，此处不重复
            model += (
                P_plan[t] + P_pv_to_load[t] + P_discharge[t] >=
                load[t] + P_charge[t] - P_pv_to_storage[t]
            )

            # 4. 储能动态约束
            model += (
                E_storage[t + 1] == E_storage[t] +
                (P_charge[t] * self.ETA_CH - P_discharge[t] / self.ETA_DIS) * self.DELTA_T
            )

            # 5. 充放电互斥约束
            model += P_charge[t] <= self.P_MAX * is_charging[t]
            model += P_discharge[t] <= self.P_MAX * (1 - is_charging[t])

        # 6. 终态自由：仅保证储能不低于下限
        model += E_storage[self.T_PERIODS] >= self.E_MIN

        # 求解
        solver = pulp.getSolver(solver_name, msg=False)
        model.solve(solver)

        if model.status != pulp.LpStatusOptimal:
            return None

        # 提取结果
        result = {
            'P_plan': np.array([P_plan[t].varValue for t in range(self.T_PERIODS)]),
            'P_charge': np.array([P_charge[t].varValue for t in range(self.T_PERIODS)]),
            'P_discharge': np.array([P_discharge[t].varValue for t in range(self.T_PERIODS)]),
            'P_pv_to_storage': np.array([P_pv_to_storage[t].varValue for t in range(self.T_PERIODS)]),
            'P_pv_to_load': np.array([P_pv_to_load[t].varValue for t in range(self.T_PERIODS)]),
            'E_storage': np.array([E_storage[t].varValue for t in range(self.T_PERIODS + 1)]),
            'total_cost': pulp.value(model.objective),
            'status': 'Optimal'
        }

        return result

    def solve_adjusted(self, price, load_forecast, pv_forecast, P_plan, E_current,
                      start_period, solver_name='PULP_CBC_CMD',
                      terminal_soc_weight=None):
        """
        6:00/12:00/18:00时刻：根据新预报调整剩余时段购电策略

        Args:
            price: 全天电价数组 (144,)
            load_forecast: 剩余时段负载预报 (remaining_periods,) — ARIMA预测
            pv_forecast: 剩余时段光伏预报 (remaining_periods,) — 附件3新预报，已插值到10分钟
            P_plan: 上一决策步骤的购电计划 (144,)，用于计算违约/超出
            E_current: 当前真实储能 kWh（来自greedy仿真）
            start_period: 调整开始时段 (36/72/108 对应 6:00/12:00/18:00)

        Returns:
            dict: P_adjusted, P_charge, P_discharge, E_storage, P_breach, P_excess,
                  breach_cost, excess_cost, total_cost, status
        """
        remaining_periods = self.T_PERIODS - start_period

        model = pulp.LpProblem(f"Problem3_Adjusted_{start_period}", pulp.LpMinimize)

        P_adjusted = [pulp.LpVariable(f"P_adj_{t}", lowBound=0)
                     for t in range(remaining_periods)]
        P_charge = [pulp.LpVariable(f"P_charge_{t}", lowBound=0, upBound=self.P_MAX)
                   for t in range(remaining_periods)]
        P_discharge = [pulp.LpVariable(f"P_discharge_{t}", lowBound=0, upBound=self.P_MAX)
                      for t in range(remaining_periods)]

        P_pv_to_storage = [pulp.LpVariable(f"P_pv_storage_{t}", lowBound=0)
                          for t in range(remaining_periods)]
        P_pv_to_load = [pulp.LpVariable(f"P_pv_load_{t}", lowBound=0)
                       for t in range(remaining_periods)]

        E_storage = [pulp.LpVariable(f"E_storage_{t}", lowBound=self.E_MIN, upBound=self.E_UPPER)
                    for t in range(remaining_periods + 1)]

        is_charging = [pulp.LpVariable(f"is_charging_{t}", cat='Binary')
                      for t in range(remaining_periods)]

        P_breach = [pulp.LpVariable(f"P_breach_{t}", lowBound=0)
                   for t in range(remaining_periods)]
        P_excess = [pulp.LpVariable(f"P_excess_{t}", lowBound=0)
                   for t in range(remaining_periods)]

        if terminal_soc_weight is None:
            terminal_soc_weight = float(np.mean(price[:36]) / self.ETA_CH)

        normal_cost = pulp.lpSum([
            P_adjusted[t] * self.DELTA_T * price[start_period + t]
            for t in range(remaining_periods)
        ])
        excess_cost_expr = pulp.lpSum([
            P_excess[t] * self.DELTA_T * price[start_period + t] * 0.5
            for t in range(remaining_periods)
        ])
        breach_cost_expr = pulp.lpSum([
            P_breach[t] * self.DELTA_T * price[start_period + t] * 0.5
            for t in range(remaining_periods)
        ])

        total_cost = normal_cost + excess_cost_expr - terminal_soc_weight * E_storage[remaining_periods]
        model += total_cost

        # 1. 当前储能初始化
        model += E_storage[0] == E_current

        for t in range(remaining_periods):
            # 2. 光伏分配约束（使用新预报，无数据泄漏）
            model += P_pv_to_load[t] + P_pv_to_storage[t] <= pv_forecast[t]

            # 3. 违约/超出定义（相对于上一决策步骤的计划）
            model += P_breach[t] >= P_plan[start_period + t] - P_adjusted[t]
            model += P_excess[t] >= P_adjusted[t] - P_plan[start_period + t]

            # 4. 功率平衡（使用预报负载）
            model += (
                P_adjusted[t] + P_pv_to_load[t] + P_discharge[t] >=
                load_forecast[t] + P_charge[t] - P_pv_to_storage[t]
            )

            # 5. 储能动态
            model += (
                E_storage[t + 1] == E_storage[t] +
                (P_charge[t] * self.ETA_CH - P_discharge[t] / self.ETA_DIS) * self.DELTA_T
            )

            # 6. 充放电互斥
            model += P_charge[t] <= self.P_MAX * is_charging[t]
            model += P_discharge[t] <= self.P_MAX * (1 - is_charging[t])

        # 7. 终态储能不低于下限
        model += E_storage[remaining_periods] >= self.E_MIN

        solver = pulp.getSolver(solver_name, msg=False)
        model.solve(solver)

        if model.status != pulp.LpStatusOptimal:
            return None

        result = {
            'P_adjusted': np.array([P_adjusted[t].varValue for t in range(remaining_periods)]),
            'P_charge': np.array([P_charge[t].varValue for t in range(remaining_periods)]),
            'P_discharge': np.array([P_discharge[t].varValue for t in range(remaining_periods)]),
            'P_pv_to_storage': np.array([P_pv_to_storage[t].varValue for t in range(remaining_periods)]),
            'P_pv_to_load': np.array([P_pv_to_load[t].varValue for t in range(remaining_periods)]),
            'E_storage': np.array([E_storage[t].varValue for t in range(remaining_periods + 1)]),
            'P_breach': np.array([P_breach[t].varValue for t in range(remaining_periods)]),
            'P_excess': np.array([P_excess[t].varValue for t in range(remaining_periods)]),
            'breach_cost': pulp.value(breach_cost_expr),
            'excess_cost': pulp.value(excess_cost_expr),
            'total_cost': pulp.value(total_cost),
            'status': 'Optimal'
        }

        return result
