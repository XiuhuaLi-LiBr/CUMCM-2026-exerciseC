"""
问题3结果保存模块
"""

import pandas as pd
import numpy as np
from pathlib import Path
from openpyxl import load_workbook
import shutil


def _fmt_date(d):
    """将日期对象格式化为 2025/2/3 格式"""
    return f'{d.year}/{d.month}/{d.day}'


def save_problem3_results(results, output_path, template_path):
    """
    保存问题3的结果到Excel文件

    Args:
        results: list of dict, 每天的优化结果
        output_path: 输出文件路径
        template_path: 模板文件路径
    """
    # 复制模板文件
    shutil.copy(template_path, output_path)

    # 加载工作簿
    wb = load_workbook(output_path)

    # 1. 保存计划购电量
    if '计划购电量' in wb.sheetnames:
        ws_plan = wb['计划购电量']
        row = 2  # 从第2行开始

        for result in results:
            date = result['date']
            P_plan = result['P_plan']

            # 日期列
            ws_plan.cell(row, 1, _fmt_date(date))

            # 144个时段的计划购电量 (kWh)
            for t in range(144):
                purchase_kwh = P_plan[t] * (1/6)  # kW * 1/6 h = kWh
                ws_plan.cell(row, t + 2, round(purchase_kwh, 4))

            # 全天购电量 (第146列)
            total_purchase_kwh = np.sum(P_plan * (1/6))
            ws_plan.cell(row, 146, round(total_purchase_kwh, 2))

            # 全天购电费 (第147列)
            total_cost = result['total_cost']
            ws_plan.cell(row, 147, round(total_cost, 2))

            row += 1

    # 2. 保存调整购电量
    if '调整购电量' in wb.sheetnames:
        ws_adj = wb['调整购电量']
        row = 2

        for result in results:
            date = result['date']

            # 日期列
            ws_adj.cell(row, 1, _fmt_date(date))

            # 获取最终购电量（可能包含调整）
            P_final = result.get('P_final', result['P_plan'])

            # 144个时段的最终购电量 (kWh)
            for t in range(144):
                purchase_kwh = P_final[t] * (1/6)
                ws_adj.cell(row, t + 2, round(purchase_kwh, 4))

            # 全天购电量 (第146列)
            total_purchase_kwh = np.sum(P_final * (1/6))
            ws_adj.cell(row, 146, round(total_purchase_kwh, 2))

            # 全天购电费 (第147列) - 使用调整后的最终费用
            total_cost_final = result.get('total_cost_final', result['total_cost'])
            ws_adj.cell(row, 147, round(total_cost_final, 2))

            row += 1

    # 3. 保存充放电量（每天6行6列，与result2格式完全一致）
    if '充放电量' in wb.sheetnames:
        ws_charge = wb['充放电量']

        time_ranges = [
            (0, 24),    # 0:00-4:00
            (24, 48),   # 4:00-8:00
            (48, 72),   # 8:00-12:00
            (72, 96),   # 12:00-16:00
            (96, 120),  # 16:00-20:00
            (120, 144)  # 20:00-24:00
        ]
        time_labels = ['0:00-4:00', '4:00-8:00', '8:00-12:00', '12:00-16:00', '16:00-20:00', '20:00-24:00']

        current_row = 2
        for result in results:
            date = result['date']
            P_charge_final = result.get('P_charge_final', result['P_charge'])
            P_discharge_final = result.get('P_discharge_final', result['P_discharge'])
            E_storage_final = result.get('E_storage_final', result['E_storage'])

            for period_idx, (start, end) in enumerate(time_ranges):
                charge_energy = np.sum(P_charge_final[start:end] * (1/6))
                discharge_energy = np.sum(P_discharge_final[start:end] * (1/6))

                # col1: 日期（只在第一行填写）
                if period_idx == 0:
                    ws_charge.cell(row=current_row, column=1, value=_fmt_date(date))
                    # col6: 0:00储电量
                    ws_charge.cell(row=current_row, column=6, value=round(E_storage_final[0], 2))

                # col2: 时间段
                ws_charge.cell(row=current_row, column=2, value=time_labels[period_idx])

                # col3: 充电量
                ws_charge.cell(row=current_row, column=3, value=round(charge_energy, 2))

                # col4: 放电量
                ws_charge.cell(row=current_row, column=4, value=round(discharge_energy, 2))

                # col6: 24:00储电量（第二行）
                if period_idx == 1:
                    ws_charge.cell(row=current_row, column=6, value=round(E_storage_final[144], 2))

                current_row += 1

    # 4. 保存紧急购电量
    if '紧急购电量' in wb.sheetnames:
        ws_emerg = wb['紧急购电量']
        row = 2

        for result in results:
            date = result['date']
            P_emergency = result.get('P_emergency', np.zeros(144))

            # 查找紧急购电时段
            emergency_periods = []
            t = 0
            while t < 144:
                if P_emergency[t] > 1e-6:  # 有紧急购电
                    # 找到连续的紧急购电时段
                    start_t = t
                    total_emergency = 0
                    while t < 144 and P_emergency[t] > 1e-6:
                        total_emergency += P_emergency[t] * (1/6)
                        t += 1
                    end_t = t

                    # 转换为时间字符串
                    start_hour = start_t // 6
                    start_min = (start_t % 6) * 10
                    end_hour = end_t // 6
                    end_min = (end_t % 6) * 10

                    time_str = f"{start_hour}:{start_min:02d}-{end_hour}:{end_min:02d}"
                    emergency_periods.append((time_str, total_emergency))
                else:
                    t += 1

            # 写入紧急购电记录（每条记录1行，3列：日期、时间段、购电量）
            if emergency_periods:
                first_record = True
                for time_str, amount in emergency_periods:
                    ws_emerg.cell(row, 1, _fmt_date(date) if first_record else None)
                    ws_emerg.cell(row, 2, time_str)
                    ws_emerg.cell(row, 3, round(amount, 2))
                    first_record = False
                    row += 1

    # 清除模板中多余的示例行（⁝ / 2025/12/31 等）
    if '计划购电量' in wb.sheetnames:
        ws_plan2 = wb['计划购电量']
        plan_last = 1 + len(results)
        if ws_plan2.max_row > plan_last:
            ws_plan2.delete_rows(plan_last + 1, ws_plan2.max_row - plan_last)

    if '调整购电量' in wb.sheetnames:
        ws_adj2 = wb['调整购电量']
        adj_last = 1 + len(results)
        if ws_adj2.max_row > adj_last:
            ws_adj2.delete_rows(adj_last + 1, ws_adj2.max_row - adj_last)

    if '充放电量' in wb.sheetnames:
        ws_charge2 = wb['充放电量']
        charge_last = 1 + len(results) * 6
        if ws_charge2.max_row > charge_last:
            ws_charge2.delete_rows(charge_last + 1, ws_charge2.max_row - charge_last)

    if '紧急购电量' in wb.sheetnames:
        emerg_last = row - 1
        ws_emerg2 = wb['紧急购电量']
        if ws_emerg2.max_row > emerg_last:
            ws_emerg2.delete_rows(emerg_last + 1, ws_emerg2.max_row - emerg_last)

    # 5. 保存购电费汇总（如果有该工作表）
    if '购电费' in wb.sheetnames:
        ws_cost = wb['购电费']

        total_cost = sum([r.get('total_cost_final', r['total_cost']) for r in results])
        ws_cost.cell(2, 2, round(total_cost, 2))

    # 保存文件
    wb.save(output_path)
    print(f"  结果已保存到: {output_path}")
