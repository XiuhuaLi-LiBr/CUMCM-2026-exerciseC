"""
问题3求解脚本（对照组）：仅用0:00预报制定全天计划，不做6/12/18时滚动调整
用于与滚动调整版本对比，验证引入额外预报是否有价值。
"""

import sys
import os
import numpy as np
import pandas as pd
from pathlib import Path
import time

sys.path.append(str(Path(__file__).parent))

from data_loader import DataLoader
from optimizer_improved_p2 import ImprovedProblem2Optimizer
from optimizer_problem3 import Problem3Optimizer
from result_saver_p3 import save_problem3_results


def greedy_simulate(pv_actual, load_actual, P_buy, E_start, t_start, t_end, opt):
    """greedy 执行仿真（与主版本相同）"""
    n = t_end - t_start
    P_ch  = np.zeros(n)
    P_dis = np.zeros(n)
    P_emg = np.zeros(n)
    E     = np.zeros(n + 1)
    E[0]  = E_start

    for j in range(n):
        t   = t_start + j
        net = P_buy[t] + pv_actual[t] - load_actual[t]

        if net >= 0.0:
            e_room = (opt.E_UPPER - E[j]) / opt.ETA_CH / opt.DELTA_T
            p_ch   = min(net, opt.P_MAX, max(e_room, 0.0))
            P_ch[j] = p_ch
            E[j+1]  = E[j] + p_ch * opt.ETA_CH * opt.DELTA_T
        else:
            need    = -net
            e_avail = (E[j] - opt.E_MIN) * opt.ETA_DIS / opt.DELTA_T
            p_dis   = min(need, opt.P_MAX, max(e_avail, 0.0))
            P_dis[j] = p_dis
            E[j+1]   = E[j] - p_dis / opt.ETA_DIS * opt.DELTA_T
            gap = need - p_dis
            if gap > 1e-6:
                P_emg[j] = gap

    return {'P_charge': P_ch, 'P_discharge': P_dis, 'P_emergency': P_emg, 'E_storage': E}


def solve_problem3_no_adjust(data_dir, output_dir, template_dir, test_mode=False):
    """
    问题3对照版：0:00制定全天计划后不再调整，直接执行 greedy 仿真。
    P_final = P_plan（全天固定），执行时用真实数据跟踪 SOC 和紧急购电。
    """
    print("=" * 60)
    print("问题3（对照）：仅0:00计划，不做6/12/18时调整")
    print("=" * 60)

    start_time = time.time()

    # 1. 加载数据
    print("\n[1/6] 加载数据...")
    loader = DataLoader(data_dir)

    data1 = loader.load_attachment1()
    price = data1['price']

    data2 = loader.load_attachment2()
    load_all   = data2['load']
    pv_all     = data2['pv_actual']
    dates_all  = data2['dates']

    data3 = loader.load_attachment3()
    forecasts = data3['forecasts']

    forecasts_npz_path = Path(output_dir) / 'forecasts_p2.npz'
    if not forecasts_npz_path.exists():
        raise FileNotFoundError(
            f"缺少预计算文件 {forecasts_npz_path}，请先运行 precompute_forecasts.py"
        )
    fc_npz = np.load(forecasts_npz_path, allow_pickle=True)
    fc_dates   = fc_npz['dates']
    fc_load    = fc_npz['load_forecast']
    fc_date_map = {pd.Timestamp(str(d)).normalize(): idx for idx, d in enumerate(fc_dates)}
    print(f"  数据加载完成。负载预报: {fc_load.shape}")

    # 2. 确定优化范围
    print("\n[2/6] 确定优化范围...")
    start_date = pd.Timestamp('2025-02-01')
    start_idx  = np.where(dates_all == start_date)[0][0]

    dates     = dates_all.iloc[start_idx:].reset_index(drop=True)
    load_data = load_all[start_idx:]
    pv_data   = pv_all[start_idx:]

    n_days = len(dates) if not test_mode else 5
    print(f"  {'测试模式' if test_mode else '完整模式'}: {n_days} 天")

    # 3. 创建优化器
    optimizer        = Problem3Optimizer()
    warmup_optimizer = ImprovedProblem2Optimizer()

    # 4. 1月暖机
    print("\n[3/6] 优化1月份（推算初始储能）...")
    E_init = 6000
    for day_idx in range(start_idx):
        result = warmup_optimizer.solve(price, load_all[day_idx], pv_all[day_idx], E_init)
        if result:
            E_init = result['E_storage'][-1]
    print(f"  2月1日初始储能: {E_init:.2f} kWh")

    # 5. 逐天求解
    print("\n[4/6] 开始优化...")
    results_all_days = []

    for i in range(n_days):
        date = dates[i]

        if (i + 1) % 30 == 0 or i == 0:
            elapsed = time.time() - start_time
            avg_time = elapsed / (i + 1 + start_idx)
            remaining_time = avg_time * (n_days - i - 1)
            print(f"  进度: {i+1}/{n_days} ({(i+1)/n_days*100:.1f}%) - "
                  f"{date.strftime('%Y-%m-%d')} - 预计剩余: {remaining_time/60:.1f}分钟")

        load_actual = load_data[i]
        pv_actual   = pv_data[i]

        # 0:00 预报
        forecast_0h = forecasts.get(date, {}).get('0:00')
        if forecast_0h is None:
            print(f"  警告: {date.strftime('%Y-%m-%d')} 缺少0:00预报，跳过")
            continue

        fc_idx  = fc_date_map.get(pd.Timestamp(date).normalize())
        load_fc = load_actual if fc_idx is None else fc_load[fc_idx]

        # 制定全天计划（唯一一次优化，不再调整）
        planned_result = optimizer.solve_planned(price, load_fc, forecast_0h, E_init)
        if planned_result is None:
            print(f"  警告: {date.strftime('%Y-%m-%d')} 计划优化失败")
            continue

        P_final = planned_result['P_plan'].copy()  # 全天固定，不调整

        # greedy 仿真全天（使用真实数据追踪实际 SOC 和紧急购电）
        P_charge_final    = np.zeros(144)
        P_discharge_final = np.zeros(144)
        P_emergency_final = np.zeros(144)
        E_storage_final   = np.zeros(145)
        E_storage_final[0] = E_init

        seg = greedy_simulate(pv_actual, load_actual, P_final, E_init, 0, 144, optimizer)
        P_charge_final[:]    = seg['P_charge']
        P_discharge_final[:] = seg['P_discharge']
        P_emergency_final[:] = seg['P_emergency']
        E_storage_final[:]   = seg['E_storage']

        # 费用计算（无调整 → breach/excess 均为 0）
        total_cost_plan       = float(np.sum(P_final * price * (1.0 / 6)))
        emergency_cost_sim    = float(np.sum(
            P_emergency_final * price * optimizer.EMERGENCY_RATIO * optimizer.DELTA_T
        ))
        total_cost_final = total_cost_plan + emergency_cost_sim

        result_day = {
            'date': date,
            'P_plan': P_final,       # 计划即最终（无调整）
            'P_final': P_final,
            'P_charge': planned_result['P_charge'],
            'P_discharge': planned_result['P_discharge'],
            'P_charge_final': P_charge_final,
            'P_discharge_final': P_discharge_final,
            'E_storage': planned_result['E_storage'],
            'E_storage_final': E_storage_final,
            'P_emergency': P_emergency_final,
            'total_cost': total_cost_plan,
            'total_cost_final': total_cost_final,
            'adjustment_costs': {'breach': 0.0, 'excess': 0.0, 'emergency': emergency_cost_sim},
        }

        results_all_days.append(result_day)
        E_init = E_storage_final[-1]

    print(f"\n  完成: {len(results_all_days)}/{n_days} 天")
    print(f"  总计算时间: {(time.time()-start_time)/60:.1f} 分钟")

    # 6. 保存结果
    print("\n[5/6] 保存结果...")
    template_path = Path(template_dir) / "result3.xlsx"
    output_path   = Path(output_dir)   / "result3_no_adjust.xlsx"
    save_problem3_results(results_all_days, output_path, template_path)

    # 7. 汇总
    print("\n[6/6] 结果汇总")
    print("=" * 60)
    total_cost     = sum(r['total_cost_final'] for r in results_all_days)
    total_purchase = sum(np.sum(r['P_final'] * (1/6)) for r in results_all_days)
    print(f"  总购电费用: {total_cost:.2f} 元")
    print(f"  总购电量:   {total_purchase:.2f} kWh")
    print(f"  平均日费用: {total_cost/len(results_all_days):.2f} 元/天")

    specified_dates = ['2025-03-20', '2025-06-21', '2025-09-23', '2025-12-21']
    print("\n指定日期的结果:")
    print("-" * 60)
    for date_str in specified_dates:
        target = pd.Timestamp(date_str)
        matches = [r for r in results_all_days if r['date'] == target]
        if matches:
            r = matches[0]
            print(f"  {date_str}:")
            print(f"    购电量: {np.sum(r['P_final']*(1/6)):.2f} kWh")
            print(f"    购电费: {r['total_cost_final']:.2f} 元")

    return results_all_days


if __name__ == "__main__":
    current_dir  = Path(__file__).parent.parent
    data_dir     = current_dir / "附件"
    output_dir   = current_dir / "results"
    template_dir = current_dir / "附件" / "附件5"
    output_dir.mkdir(exist_ok=True)

    test_mode = '--test' in sys.argv
    solve_problem3_no_adjust(data_dir, output_dir, template_dir, test_mode=test_mode)
