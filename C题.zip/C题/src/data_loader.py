"""
数据加载模块
负责从Excel文件读取所有附件数据
"""

import pandas as pd
import numpy as np
from pathlib import Path


class DataLoader:
    """数据加载器"""

    def __init__(self, data_dir):
        """
        初始化数据加载器

        Args:
            data_dir: 附件数据所在目录
        """
        self.data_dir = Path(data_dir)

    def load_attachment1(self):
        """
        加载附件1：典型日数据

        Returns:
            dict: {
                'price': 电价数组 (144,)
                'load': 负载数组 (144,)
                'pv_forecast': 光伏预测数组 (144,)
            }
        """
        file_path = self.data_dir / '附件1.xlsx'
        df = pd.read_excel(file_path)

        # 提取数据（根据实际列名）
        data = {
            'price': df['电价'].values,
            'load': df['小区负载'].values,
            'pv_forecast': df['光伏发电预测功率'].values
        }

        return data

    def load_attachment2(self):
        """
        加载附件2：2025年全年实际数据

        Returns:
            dict: {
                'load': DataFrame (365天 × 144时段)
                'pv_actual': DataFrame (365天 × 144时段)
            }
        """
        file_path = self.data_dir / '附件2.xlsx'

        # 读取负载数据
        load_df = pd.read_excel(file_path, sheet_name='小区负载')
        # 第一列是日期，后面144列是数据
        load_data = load_df.iloc[:, 1:145].values  # (365, 144)

        # 读取光伏实际功率数据
        pv_df = pd.read_excel(file_path, sheet_name='光伏发电实际功率')
        pv_data = pv_df.iloc[:, 1:145].values  # (365, 144)

        # 提取日期
        dates = pd.to_datetime(load_df.iloc[:, 0])

        data = {
            'load': load_data,
            'pv_actual': pv_data,
            'dates': dates
        }

        return data

    def load_attachment3(self):
        """
        加载附件3：光伏发电预报数据

        Returns:
            dict: {
                'forecasts': DataFrame with columns [date, forecast_time, hour_1, ..., hour_24]
                或组织成嵌套字典 {date: {time: array}}
            }
        """
        file_path = self.data_dir / '附件3.xlsx'
        df = pd.read_excel(file_path)

        # 组织预报数据为嵌套字典: {date: {forecast_time: hourly_forecast_array}}
        forecasts = {}
        current_date = None

        for idx, row in df.iterrows():
            # 如果日期列不为空，更新当前日期
            if pd.notna(row.iloc[0]):  # 第一列是日期
                date_val = row.iloc[0]
                if isinstance(date_val, pd.Timestamp):
                    current_date = date_val
                else:
                    # 尝试解析字符串日期
                    current_date = pd.to_datetime(str(date_val))

                forecasts[current_date] = {}

            # 预报时刻（第二列）
            forecast_time = str(row.iloc[1])  # '0:00', '6:00', '12:00', '18:00'

            # 提取24小时预报数据（从第3列开始）
            forecast_24h = row.iloc[2:26].values.astype(float)

            if current_date is not None:
                forecasts[current_date][forecast_time] = forecast_24h

        return {'forecasts': forecasts}

    def load_attachment4(self):
        """
        加载附件4：波动电价数据

        Returns:
            dict: {
                'prices': numpy array shape (365, 144), 每行是一天144个时段的电价
                'dates': pandas Series of Timestamps
            }
        """
        file_path = self.data_dir / '附件4.xlsx'
        df = pd.read_excel(file_path)

        # 第一列是日期，后面144列是电价数据
        dates = pd.to_datetime(df.iloc[:, 0])
        prices = df.iloc[:, 1:145].values.astype(float)  # (365, 144)

        return {
            'prices': prices,
            'dates': dates
        }


def interpolate_hourly_to_10min(hourly_data):
    """
    将整点预报数据插值到10分钟间隔

    Args:
        hourly_data: 整点数据 (25个点: 0:00到24:00)

    Returns:
        np.array: 10分钟数据 (144个点)
    """
    if len(hourly_data) == 25:
        # 线性插值
        from scipy.interpolate import interp1d
        hours = np.arange(25) / 24 * 144  # 映射到144个时间段
        time_10min = np.arange(144)

        f = interp1d(hours, hourly_data, kind='linear')
        data_10min = f(time_10min)

        return data_10min
    elif len(hourly_data) == 144:
        # 已经是10分钟数据
        return np.array(hourly_data)
    else:
        raise ValueError(f"Unexpected data length: {len(hourly_data)}")


def parse_time_index(time_str):
    """
    解析时间字符串到时间段索引

    Args:
        time_str: 如 "10:00" 或 "10:10"

    Returns:
        int: 时间段索引 (0-143)
    """
    parts = time_str.split(':')
    hour = int(parts[0])
    minute = int(parts[1])

    # 计算时间段索引
    index = hour * 6 + minute // 10

    return index


def create_time_array():
    """
    创建时间标签数组

    Returns:
        list: 144个时间标签 ["0:00", "0:10", ..., "23:50"]
    """
    time_labels = []
    for h in range(24):
        for m in range(0, 60, 10):
            time_labels.append(f"{h:02d}:{m:02d}")

    return time_labels


if __name__ == "__main__":
    # 测试数据加载
    loader = DataLoader("../附件")

    print("测试加载附件1...")
    data1 = loader.load_attachment1()
    print(f"电价shape: {data1['price'].shape}")
    print(f"负载shape: {data1['load'].shape}")
    print(f"光伏预测shape: {data1['pv_forecast'].shape}")

    print("\n时间标签示例:")
    times = create_time_array()
    print(times[:10])
    print(f"总共{len(times)}个时间段")
